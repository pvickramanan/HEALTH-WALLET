**Its Done As a College Project**
This is a python and backbone.js application done as part of college final project for an IIT student, 
The technologies using here are

* `Python`
* `Flask`
* `MongoDB`
* `backbonejs`
* `HTML`
* `CSS`
* `Bootsrap`

For Runing the project First clone the project or download the project using the command

`git clone <git url>`

Move the   `front-end` directory to the Apache directory or change the apache conf file for changing the apache doc path

**Prerequisite**
System must be installed with 
* `MongoDB`
* `Python` (3.6 or higher)




***
This section is not related to the project This is added just for **Educational** Purpose only.

**Start Mongo DB docker image**

`docker run -p 27017:27017 -d --network mongo-network --name mongodb mongo`

**Start Mongo Express UI for mongoDB**

`docker run -p 8081:8081 -d --network mongo-network --name mongodb-express -e ME_CONFIG_MONGODB_SERVER=mongodb mongo-express`


`https://stackoverflow.com/questions/64796701/problems-installing-mongodb-on-ubuntu-20-04`
