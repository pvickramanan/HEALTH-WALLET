# activating the virtual env
# source ~/anaconda3/bin/activate

# Kill if the api is running already
# lsof -i tcp:5004 | awk '{print $2}' | tail -1 | xargs --no-run-if-empty kill -9

# Moving to the api directory
# cd /Users/sajikumar/PycharmProjects/HealthWallet/health_wallet

export FLASK_APP=app.py

# starting the api and storing logs in flask.log file in root directory
# nohup flask run --host=0.0.0.0 -p 5004 > flask.log 2>&1 &
flask run --host=0.0.0.0 -p 17000