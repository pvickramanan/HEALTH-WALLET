__author__ = "sajikumar"


class PrefixMiddleware(object):

    def __init__(self, app, prefix=''):
        self.app = app
        self.prefix = prefix

    def __call__(self, environ, start_response):

        if environ['PATH_INFO'].startswith(self.prefix):
            environ['PATH_INFO'] = environ['PATH_INFO'][len(self.prefix):]
            environ['SCRIPT_NAME'] = self.prefix
            return self.app(environ, start_response)
        else:
            start_response('404', [('Content-Type', 'text/plain')])
            return ["This url does not belong to the app.".encode()]


def result_success_template(message=None):
    if message:
        return {'status': 'success', 'message': message}
    else:
        return {'status': 'success', 'message': 'Successfully processed'}


def result_error_template(message=None):
    if message:
        return {'status': 'error', 'message': message}
    else:
        return {'status': 'error', 'message': 'Error while processing the request'}