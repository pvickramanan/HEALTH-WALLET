__author__ = "ajeesh"


import pymongo


myclient = pymongo.MongoClient("mongodb://localhost:27017/")


def create_client():
    mydb = myclient["hospital"]
    return mydb