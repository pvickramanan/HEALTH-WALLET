import base64
import json


def request_params(request):
    data = base64.b64decode(request.args.get('_session')).decode()
    return json.loads(data)
