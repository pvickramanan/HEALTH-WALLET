__author__ = "ajeesh"


from datetime import datetime


def calculate_age(str_date):
    if str_date:
        born = datetime.strptime(str_date, "%m/%d/%Y")
        today = datetime.now()
        return today.year - born.year - ((today.month, today.day) < (born.month, born.day))