__author__ = "ajeesh"

import json
import logging
import traceback

from services import loginServices, adminService, bloodBankService, hospitalService, diseaseService, doctorService,\
    appointmentService, signupService
from services import patientService, profileService, medicineService, labtestService
import utils.service_utils as utils
from flask_cors import CORS
from flask import Flask, request, send_from_directory


app = Flask(__name__)  # creating the Flask class object
app.debug = True
app.wsgi_app = utils.PrefixMiddleware(app.wsgi_app, prefix='/hw/v1/')

# ---------------------------------- CORS configurations for Service endpoints -------------------------
CORS(app, resources={
    r"/*": {"origins": "*"}
})


# Sample upload window for testing purpose
# get method for showing upload screen
# http://127.0.0.1:17000/hw/v1/index
@app.route("/index", methods=['GET'])
def get_main_html():
    return send_from_directory("./", "templates/index.html")


# Login service to authorise user
# post method for user authentication
# http://127.0.0.1:17000/hw/v1/login
@app.route("/login", methods=['POST'])
def login_check():
    try:
        print('login Request')
        logging.info('Login into CRM')
        data = loginServices.user_authentication(request)

        response = utils.result_success_template("success")
        response["data"] = data
        return json.dumps(response)
    except Exception as e:
        logging.error(traceback.format_exc())
        return json.dumps(utils.result_error_template(str(e)))


@app.route("/changePassword", methods=['POST'])
def change_password():
    try:
        print('login Request')
        logging.info('Login into CRM')
        data = loginServices.user_change_password(request)

        response = utils.result_success_template("success")
        response["status"] = "success" if data else "failed"
        response["result"] = {"status": "success" if data else "failed"}
        return json.dumps(response)
    except Exception as e:
        logging.error(traceback.format_exc())
        return json.dumps(utils.result_error_template(str(e)))


# admin dashboard service for landing page data
# get method for admin landing page
# http://127.0.0.1:17000/hw/v1/admin
@app.route("/dashboard", methods=['POST'])
def admin_landing_page():
    try:
        data = adminService.admin_landing_page(request)

        response = utils.result_success_template("success")
        response["data"] = data
        return json.dumps(response)
    except Exception as e:
        logging.error(traceback.format_exc())
        return json.dumps(utils.result_error_template(str(e)))


# bloodbank service for landing page data
# get method for blood bank
# http://127.0.0.1:17000/hw/v1/bloodbank
@app.route("/bloodbank", methods=['GET'])
def blood_bank_page():
    try:
        data = bloodBankService.blood_bank_page()

        response = utils.result_success_template("success")
        response["data"] = data
        return json.dumps(response)
    except Exception as e:
        logging.error(traceback.format_exc())
        return json.dumps(utils.result_error_template(str(e)))


@app.route("/bloodbank/getDetails", methods=['POST'])
def blood_bank_details():
    try:
        data = bloodBankService.blood_bank_details(request)

        response = utils.result_success_template("success")
        response["data"] = data
        return json.dumps(response)
    except Exception as e:
        logging.error(traceback.format_exc())
        return json.dumps(utils.result_error_template(str(e)))


@app.route("/bloodbank/updateDetails", methods=['POST'])
def blood_bank_update_details():
    try:
        data = bloodBankService.update_blood_bank_details(request)

        response = utils.result_success_template("success")
        response["data"] = data
        return json.dumps(response)
    except Exception as e:
        logging.error(traceback.format_exc())
        return json.dumps(utils.result_error_template(str(e)))


@app.route("/bloodbank/saveDetails", methods=['POST'])
def blood_bank_save_details():
    try:
        data = bloodBankService.save_blood_bank_details(request)

        response = utils.result_success_template("success")
        response["data"] = data
        return json.dumps(response)
    except Exception as e:
        logging.error(traceback.format_exc())
        return json.dumps(utils.result_error_template(str(e)))


@app.route("/bloodbank/delete", methods=['POST'])
def delete_blood_bank():
    try:
        data = bloodBankService.delete_blood_bank(request)

        response = utils.result_success_template("success")
        response["data"] = data
        return json.dumps(response)
    except Exception as e:
        logging.error(traceback.format_exc())
        return json.dumps(utils.result_error_template(str(e)))


# hospitals service for landing page data
# get method for blood bank
# http://127.0.0.1:17000/hw/v1/hospitals
@app.route("/hospitals", methods=['POST'])
def hospitals_bank_page():
    try:
        data = hospitalService.hospitals_bank_page()

        response = utils.result_success_template("success")
        response["data"] = data
        return json.dumps(response)
    except Exception as e:
        logging.error(traceback.format_exc())
        return json.dumps(utils.result_error_template(str(e)))


# hospitals to create doctor
# http://127.0.0.1:17000/hw/v1/hospitals/createdoctor
@app.route("/hospitals/createDoctor", methods=['POST'])
def create_doctor():
    try:
        data = hospitalService.create_doctor(request)
        response = utils.result_success_template("success")
        response["data"] = data
        return json.dumps(response)
    except Exception as e:
        logging.error(traceback.format_exc())
        return json.dumps(utils.result_error_template(str(e)))


# diseases service for landing page data
# get method for diseases
# http://127.0.0.1:17000/hw/v1/diseases
@app.route("/diseases", methods=['POST'])
def get_diseases_details():
    try:
        data = diseaseService.get_diseases_details(request)

        response = utils.result_success_template("success")
        response["data"] = data
        return json.dumps(response)
    except Exception as e:
        logging.error(traceback.format_exc())
        return json.dumps(utils.result_error_template(str(e)))


# doctors service for landing page data
# get method for doctors
# http://127.0.0.1:17000/hw/v1/doctors
@app.route("/doctors", methods=['POST'])
def get_doctors_details():
    try:
        data = doctorService.get_doctors_details(request)

        response = utils.result_success_template("success")
        response["data"] = data
        return json.dumps(response)
    except Exception as e:
        logging.error(traceback.format_exc())
        return json.dumps(utils.result_error_template(str(e)))


# patients service for landing page data
# get method for patients
# http://127.0.0.1:17000/hw/v1/patients
@app.route("/patients", methods=['POST'])
def get_patients_details():
    try:
        data = patientService.get_patient_details(request)

        response = utils.result_success_template("success")
        response["data"] = data
        return json.dumps(response)
    except Exception as e:
        logging.error(traceback.format_exc())
        return json.dumps(utils.result_error_template(str(e)))


# doctors service for landing page data
# get method for doctors
# http://127.0.0.1:17000/hw/v1/patient/search
@app.route("/patient/search", methods=['POST'])
def search_patient():
    try:
        data = patientService.search_patient(request)

        response = utils.result_success_template("success")
        response["data"] = data
        return json.dumps(response)
    except Exception as e:
        logging.error(traceback.format_exc())
        return json.dumps(utils.result_error_template(str(e)))


# patients service for landing page data
# get method for patients
# http://127.0.0.1:17000/hw/v1/patients
@app.route("/profile", methods=['POST', 'PUT'])
def get_profile_details():
    try:
        if request.method == 'POST':
            data = profileService.get_profile_details(request)
        else:
            data = profileService.update_profile_details(request)
        response = utils.result_success_template("success")
        response["data"] = data
        return response
    except Exception as e:
        logging.error(traceback.format_exc())
        return json.dumps(utils.result_error_template(str(e)))


# patients service for landing page data
# get method for patients
# http://127.0.0.1:17000/hw/v1/patients/medicalHistory
@app.route("/patients/medicalHistory", methods=['GET'])
def get_medical_history():
    try:
        data = appointmentService.get_medical_history(request)

        response = utils.result_success_template("success")
        response["data"] = data
        return json.dumps(response)
    except Exception as e:
        logging.error(traceback.format_exc())
        return json.dumps(utils.result_error_template(str(e)))


# patients service for landing page data
# get method for patients
# http://127.0.0.1:17000/hw/v1/patients/bookAppointment
@app.route("/patients/bookAppointment", methods=['POST'])
def book_appointment():
    try:
        data = appointmentService.create_appointment(request)

        response = utils.result_success_template("success")
        response["data"] = data
        return json.dumps(response)
    except Exception as e:
        logging.error(traceback.format_exc())
        return json.dumps(utils.result_error_template(str(e)))


# patients service for landing page data
# get method for patients
# http://127.0.0.1:17000/hw/v1/hospital/appointment
@app.route("/hospital/appointment", methods=['POST'])
def hs_appointment():
    try:
        data = appointmentService.hospital_appointment(request)

        response = utils.result_success_template("success")
        response["data"] = data
        return json.dumps(response)
    except Exception as e:
        logging.error(traceback.format_exc())
        return json.dumps(utils.result_error_template(str(e)))


# get appointment details for all users according to the role
# get method for patients
# http://127.0.0.1:17000/hw/v1/getAppointment
@app.route("/getAppointment", methods=['POST'])
def get_appointment():
    try:
        data = appointmentService.get_appointment(request)

        response = utils.result_success_template("success")
        response["data"] = data
        return json.dumps(response)
    except Exception as e:
        logging.error(traceback.format_exc())
        return json.dumps(utils.result_error_template(str(e)))


# edit already created appointment
# http://127.0.0.1:17000/hw/v1/updateAppointment
@app.route("/updateAppointment", methods=['POST'])
def edit_appointment():
    try:
        data = appointmentService.update_appointment(request)
        response = utils.result_success_template("success")
        response["data"] = data
        return response
    except Exception as e:
        logging.error(traceback.format_exc())
        return json.dumps(utils.result_error_template(str(e)))


# add doctor prescription after appointment
# http://127.0.0.1:17000/hw/v1/addPrescription
@app.route("/addPrescription", methods=['POST'])
def add_prescription():
    try:
        data = appointmentService.add_prescription(request)
        response = utils.result_success_template("success")
        response["data"] = data
        return response
    except Exception as e:
        logging.error(traceback.format_exc())
        return json.dumps(utils.result_error_template(str(e)))


# consult an already created appointment
# http://127.0.0.1:17000/hw/v1/consultPatient
@app.route("/consultPatient", methods=['POST'])
def consult_appointment():
    try:
        data = appointmentService.consult_appointment(request)
        response = utils.result_success_template("success")
        response["data"] = data
        return response
    except Exception as e:
        logging.error(traceback.format_exc())
        return json.dumps(utils.result_error_template(str(e)))


# delete an existing appointment
# http://127.0.0.1:17000/hw/v1/deleteAppointment
@app.route("/deleteAppointment", methods=['POST'])
def delete_appointment():
    try:
        data = appointmentService.delete_appointment(request)
        response = utils.result_success_template("success")
        response["data"] = data
        return response
    except Exception as e:
        logging.error(traceback.format_exc())
        return json.dumps(utils.result_error_template(str(e)))


# doctors service for landing page data
# get method for doctors
# http://127.0.0.1:17000/hw/v1/search/medicine
@app.route("/search/medicine", methods=['POST'])
def search_medicine():
    try:
        data = medicineService.search_medicine(request)

        response = utils.result_success_template("success")
        response["data"] = data
        return json.dumps(response)
    except Exception as e:
        logging.error(traceback.format_exc())
        return json.dumps(utils.result_error_template(str(e)))


# Diagonise Appointment Get Specimen Data
# get method Lab Tests
# http://127.0.0.1:17000/hw/v1/labtest/specimen
@app.route("/labtest/specimen", methods=['GET', 'POST'])
def specimen():
    try:
        data = labtestService.get_specimen(request)
        response = utils.result_success_template("success")
        response["data"] = data
        return response
    except Exception as e:
        logging.error(traceback.format_exc())
        return json.dumps(utils.result_error_template(str(e)))


# get email-id of the user during sign-up
# check whether user with same email-id already exists
# http://127.0.0.1:17000/hw/v1//signup/validation
@app.route("/signup/emailVerification", methods=['POST'])
def signup_validation():
    try:
        data = signupService.signup_validation_service(request)
        res = utils.result_success_template()
        res['data'] = data
        return res
    except Exception as e:
        logging.error(traceback.format_exc())
        return json.dumps(utils.result_error_template(str(e)))


# create new patient
# check whether user with same email-id already exists
# http://127.0.0.1:17000/hw/v1//signup
@app.route("/signup", methods=['POST'])
def register():
    try:
        data = signupService.register_user(request)
        res = utils.result_success_template()
        res['data'] = data
        return res
    except Exception as e:
        logging.error(traceback.format_exc())
        return json.dumps(utils.result_error_template(str(e)))


# create new patient
# check whether user with same email-id already exists
# http://127.0.0.1:17000/hw/v1//feedback
@app.route("/feedback", methods=['POST'])
def feedback():
    try:
        data = signupService.submit_feedback(request)
        res = utils.result_success_template()
        res['data'] = data
        return res
    except Exception as e:
        logging.error(traceback.format_exc())
        return json.dumps(utils.result_error_template(str(e)))


if __name__ == '__main__':
    app.run(host="0.0.0.0", debug=True, port=17000)
    # app.run()
