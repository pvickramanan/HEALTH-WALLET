__author__ = "ajeesh"

import json

from utils import dbutil, utils
from datetime import datetime


def search_medicine(request):
    db = dbutil.create_client()
    data = {"result": []}
    res = []
    input_json = json.loads(request.get_data())
    query = {"$text": {"$search": input_json.get('text')}}
    query = {"name" : {"$regex" : input_json.get('text')}}
    res = db.medicine.find(query)
    for item in res:
        item.pop("_id")
        data["result"].append(item)

    return data