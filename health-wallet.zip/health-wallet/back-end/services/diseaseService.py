__author__ = "ajeesh"

import json

from utils import dbutil


def get_diseases_details(request):
    input_json = json.loads(request.get_data())
    db = dbutil.create_client()
    res = []
    data = {"result": []}
    if input_json.get("role", "") == "hospital":
        hs_res = db.hospitals.find_one({"email": input_json.get("username")})
        if hs_res:
            hospital_id = hs_res.get("id")
            res = db.patients.find({"hospital_id": hospital_id})
            result = {}
            for item in res:
                if item['condition'] not in result:
                    result[item['condition']] = {'patient': 1, 'departments': [], 'name': item['condition']}
                    result[item['condition']]['male'] = 0
                    result[item['condition']]['female'] = 0
                    result[item['condition']]['departments'] = [item['department']]
                else:
                    result[item['condition']]['patient'] += 1
                if item['department'] not in result[item['condition']]['departments']:
                    result[item['condition']]['departments'].append(item['department'])
                if item['gender'].lower() in result[item['condition']]:
                    result[item['condition']][item['gender'].lower()] += 1
            data["result"] = [val for key, val in result.items()]
            data['header'] = [{"head": "Name", "key": "name"}, {"head": "Departments", "key": "departments"},
                              {"head": "Patient", "key": "patient"}, {"head": "Male", "key": "male"},
                              {"head": "Female", "key": "female"}]
            return data

    else:
        res = db.diseases.find({})
    for item in res:
        item.pop("_id")
        data["result"].append(item)

    return data
