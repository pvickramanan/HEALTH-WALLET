__author__ = "ajeesh"

import json

import requests
from utils import dbutil
import uuid


def hospitals_bank_page():
    db = dbutil.create_client()
    res = db.hospitals.find({})
    data = {"result": []}
    available = 0
    capacity = 0
    for item in res:
        item.pop("_id")
        data["result"].append(item)
    data["available"] = available
    data["capacity"] = capacity
    return data


def create_doctor(request):
    db = dbutil.create_client()
    res = []
    input_json = json.loads(request.get_data())
    search_result = db.doctors.find({"email": input_json.get("email")})
    res = list(search_result)
    if len(res) > 0:
        return {"status": False, "message": "Email Id already exists"}
    else:
        input_json["id"] = str(uuid.uuid4()).replace("-", "")
        res = db.doctors.insert_one(input_json)
        search_res = []
        search_hosp = db.hospitals.find_one({"id": input_json.get("hospital_id")})
        if input_json.get("department") not in search_hosp["departments"].keys():
            search_hosp["departments"][input_json.get("department")] = {"patients": 0,
                                                                        "doctors": [{"name": input_json.get("name"),
                                                                                     "id": input_json["id"]}]}
        else:
            search_hosp["departments"][input_json.get("department")]["doctors"].append({"name": input_json.get("name"),
                                                                                        "id": input_json["id"]})
        db.hospitals.update_one({"id": input_json.get("hospital_id")},
                                {"$set": {"departments": search_hosp["departments"]}})
        return {"status": True, "message": input_json.get("id")}


def get_landing_page(input_json):
    db = dbutil.create_client()
    hs_res = db.hospitals.find_one({"email": input_json.get("username")})
    return hs_res