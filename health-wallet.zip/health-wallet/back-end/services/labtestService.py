__author__ = "ajeesh"

import json
import re

from utils import dbutil, utils


def get_specimen(request):
    db = dbutil.create_client()
    data = {"result": []}
    specimen = request.args.get('specimen')
    if specimen:
        query = {"specimen": re.compile(specimen, re.IGNORECASE)}
        result = db.labtests.find(query)
        if result:
            for item in result:
                item.pop("_id")
                data["result"].append(item)
    else:
        result = db.labtests.distinct("specimen")
        if "—" in result:
            result.remove("—")
        data["result"] = result

    return data
