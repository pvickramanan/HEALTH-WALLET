__author__ = "ajeesh"

import json
import base64
from utils import dbutil


# For user authentication
def user_authentication(request):
    input_json = json.loads(request.get_data())
    userName = input_json.get('userName')
    if not userName:
        userName = input_json.get('username')
    password = base64.b64decode(input_json['password']).decode()
    db = dbutil.create_client()
    my_col = db["login"]
    user_input = {"username": userName, "password": password}
    print(user_input)
    out_data = my_col.find(user_input)

    data = {}
    for x in out_data:
        data["username"] = x["username"]
        data["role"] = x["role"]
        data["email"] = x["email"]
        data["name"] = x["name"]
        if data['role'] == "hospital":
            hs_res = db.hospitals.find_one({"email": input_json.get("userName")})
            if hs_res:
                data["name"] = hs_res['name']
    return data


def user_change_password(request):
    try:
        input_json = json.loads(request.get_data())
        userName = input_json['username']
        newPassword = input_json['newPass']
        password = base64.b64decode(input_json['password']).decode()
        db = dbutil.create_client()
        my_col = db["login"]
        user_input = {"username": userName, "password": password}
        print(user_input)
        my_col.update_one(user_input, {'$set': {"password": newPassword}})
        return True
    except Exception as e:
        return False
