__author__ = "ajeesh"

import json
import traceback
import uuid

from utils import dbutil


def blood_bank_page():
    db = dbutil.create_client()
    res = db.bloodbank.find({})
    data = {"result": []}
    available = 0
    capacity = 0
    for item in res:
        item.pop("_id")
        try:
            for key in item:
                if key not in ["name", "location", "id", "email", "phone"]:
                    available += int(item[key]["available"])
                    capacity += int(item[key]["capacity"])
            data["result"].append(item)
        except Exception as e:
            print(traceback.print_exc())
            print(item)
            continue
    data["available"] = available
    data["capacity"] = capacity
    return data


def blood_bank_details(request):
    db = dbutil.create_client()
    input_json = json.loads(request.get_data())
    res = db.bloodbank.find(input_json)
    for item in res:
        item.pop("_id")
        return item
    return {}


def update_blood_bank_details(request):
    db = dbutil.create_client()
    input_json = json.loads(request.get_data())
    query = {"id": input_json['id']}
    values = {"$set": input_json}

    db.bloodbank.update_one(query, values)

    return {"success": True}


def save_blood_bank_details(request):
    db = dbutil.create_client()
    input_json = json.loads(request.get_data())
    input_json["id"] = str(uuid.uuid4()).replace("-", "")
    print(input_json)
    db.bloodbank.insert_one(input_json)

    return {"success": True}


def delete_blood_bank(request):
    db = dbutil.create_client()
    input_json = json.loads(request.get_data())
    db.bloodbank.delete_one(input_json)

    return {"success": True, "status": "success"}