__author__ = "ajeesh"

import json

from utils import dbutil, utils
from datetime import datetime


def get_patient_details(request):
    db = dbutil.create_client()
    data = {"result": []}
    res = []
    input_json = json.loads(request.get_data())
    input_text = input_json.get('input')
    admin_query = {}
    if input_text and input_text != "":
        admin_query = {"name": {'$regex': input_text}}
    if input_json.get("role", "") == "hospital":
        hs_res = db.hospitals.find_one({"email": input_json.get("username")})
        if hs_res:
            hospital_id = hs_res.get("id")
            res = db.patients.find({"hospital_id": hospital_id})
    elif input_json.get("role", "") == "doctor":
        hs_res = db.doctors.find_one({"email": input_json.get("username")})
        if hs_res:
            doctor_id = hs_res.get("id")
            res = db.patients.find({"doctor_id": doctor_id})
    else:
        if input_text:
            res = db.patients.find(admin_query)
        else:
            res = db.patients.find(admin_query).limit(3000)
    for item in res:
        item.pop("_id")
        item['age'] = utils.calculate_age(item['date_of_birth'])
        data["result"].append(item)
    return data


def search_patient(request):
    db = dbutil.create_client()
    data = {"result": []}
    res = []
    input_json = json.loads(request.get_data())
    query = {"$text": {"$search": f"\"{input_json.get('text')}\""}}
    res = db.patients.find(query)
    for item in res:
        item.pop("_id")
        item['age'] = utils.calculate_age(item['date_of_birth'])
        data["result"].append(item)

    return data