__author__ = "ajeesh"

import datetime
import json

from utils import dbutil, utils


def get_profile_details(request):
    db = dbutil.create_client()
    data = {"result": []}
    res = {}
    input_json = json.loads(request.get_data())
    query = {"email": input_json.get("username")}
    print(query)
    if input_json.get("role", "") == "hospital":
        res = db.hospitals.find_one(query)
    elif input_json.get("role", "") == "doctor":
        res = db.doctors.find_one(query)
        hs_id = res.get('hospital_id')
        hs_details = {}
        if hs_id:
            hs_res = db.hospitals.find_one({"id": hs_id})
            hs_res.pop("_id")
            hs_details = hs_res
        res["hospital_details"] = hs_details

    elif input_json.get("role", "") == "patient":
        res = db.patients.find_one(query)
    res.pop("_id")
    res['age'] = utils.calculate_age(res.get('date_of_birth'))
    data["result"] = res
    return data


def update_profile_details(request):
    try:
        db = dbutil.create_client()
        input_json = json.loads(request.get_data())
        query = {"email": input_json.get("username")}
        if input_json.get('role') == "patient":
            db.patients.update_one(query, {"$set": {"name": input_json["name"],
                                                    "date_of_birth": input_json["date_of_birth"],
                                                    "gender": input_json['gender'],
                                                    "address": input_json["address"],
                                                    "phone": input_json.get("phone"),
                                                    "city": input_json.get("city"),
                                                    }
                                           })
        elif input_json.get('role') == "doctor":
            db.doctors.update_one(query, {"$set": {"name": input_json["name"],
                                                   "date_of_birth": input_json["date_of_birth"],
                                                   "gender": input_json['gender'],
                                                   "address": input_json["address"],
                                                   "phone": input_json.get("phone"),
                                                   "qualification": input_json.get("qualification"),
                                                   "pincode": input_json.get("pincode"),
                                                   "district": input_json.get("district"),
                                                   }
                                          })
        elif input_json.get('role') == "hospital":
            db.hospitals.update_one(query, {"$set": {"name": input_json["name"],
                                                     "address": input_json["address"],
                                                     "phone": input_json.get("phone"),
                                                     "pincode": input_json.get("pincode"),
                                                     "district": input_json.get("district"),
                                                     "icu_beds": input_json.get("icu_beds"),
                                                     "oxygen_cylinders": input_json.get("oxygen_cylinders"),
                                                     "patient_capacity": input_json.get("patient_capacity"),
                                                     }
                                            })
        return {"success": True, "message": "success"}
    except Exception as e:
        return {"success": False, "message": str(e)}
