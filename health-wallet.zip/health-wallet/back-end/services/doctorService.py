__author__ = "ajeesh"

import json

from utils import dbutil
from datetime import datetime


def get_doctors_details(request):
    db = dbutil.create_client()
    data = {"result": []}
    res = []
    input_json = json.loads(request.get_data())
    if input_json.get("role", "") == "hospital":
        hs_res = db.hospitals.find_one({"email": input_json.get("username")})
        if hs_res:
            hospital_id = hs_res.get("id")
            res = db.doctors.find({"hospital_id": hospital_id})
    else:
        res = db.doctors.find({})
    for item in res:
        item.pop("_id")
        item['age'] = calculate_age(item['date_of_birth'])
        data["result"].append(item)

    return data


def calculate_age(str_date):
    born = datetime.strptime(str_date, "%m/%d/%Y")
    today = datetime.now()
    return today.year - born.year - ((today.month, today.day) < (born.month, born.day))