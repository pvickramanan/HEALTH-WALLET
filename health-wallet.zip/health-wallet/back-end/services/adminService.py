__author__ = "sajikumar"

import json
from datetime import datetime

from utils import dbutil
from services import dummy_data, hospitalService


out_template = {"bar_chart_data":{},"line_chart_data":{},"name":"Admin","total_doctors":2123,"total_patients":31190,"total_icu_beds":1234,"oxygen_availability":724,"hospital_management":[],"hospital_details":[],"disease_details":[],"lab_details":[]}


def admin_landing_page(request):
    db = dbutil.create_client()
    input_json = json.loads(request.get_data())
    out_temp = dummy_data.admin
    print(input_json)
    if input_json.get("role") == "hospital":
        res = hospitalService.get_landing_page(input_json)
        out_temp["name"] = res['name']
        out_temp["oxygen_availability"] = res['oxygen_cylinders']
        out_temp["total_icu_beds"] = res['icu_beds']
        total_doc = 0
        patients = 0
        for key, val in res['departments'].items():
            total_doc += len(val['doctors'])
            patients += int(val['patients'])
        out_temp["total_doctors"] = total_doc
        out_temp["total_patients"] = patients
        out_temp["bar_chart_data"], out_temp["line_chart_data"] = get_bar_graph(db, {'hospital_id': res['id']})
        out_temp["disease_details"] = get_disease_details({'hospitals': res['id']}, db)
        out_temp["hospital_details"] = {"label": "Doctors Lists",
                                        "data": get_doctors_details({'hospital_id': res['id']}, db),
                                        "href": "#doctorsDetails"}
    else:

        out_temp["oxygen_availability"] = get_sum_of_filed('oxygen_cylinders', db)
        out_temp["total_icu_beds"] = get_sum_of_filed('icu_beds', db)
        out_temp["total_doctors"] = db.doctors.count_documents({})
        out_temp["total_patients"] = db.patients.count_documents({})
        out_temp["disease_details"] = get_disease_details({}, db)
        out_temp["bar_chart_data"], out_temp["line_chart_data"] = get_bar_graph(db)
        out_temp["hospital_details"] = {"label": "Hospital Lists", "data": get_hospital_details({}, db),
                                        "href": "#hospitalsDetails"}
    return out_temp


def get_sum_of_filed(attr, db):
    pipe = [{'$group': {'_id': None, 'total': {'$sum': '$'+attr}}}]
    res = db.hospitals.aggregate(pipeline=pipe)
    for item in res:
        return item['total']
    return 0


def get_disease_details(query, db):
    data = []
    print(query)
    res = db.diseases.find(query).sort("patient", -1).limit(6)
    for item in res:
        item.pop("_id")
        data.append(item)
    return data


def get_hospital_details(query, db):
    data = []
    print(query)
    res = db.hospitals.find(query).sort("patient_capacity", -1).limit(5)
    for item in res:
        res_item = {}
        item.pop("_id")
        res_item["name"] = {"name": item["name"], "location": item["location"], "href": "#hospitals"}
        res_item['departments'] = {"departments": len(item['departments'].keys()), "label": "Departments"}
        tot_pt = 0
        for key in item['departments'].keys():
            tot_pt += int(item["departments"][key]["patients"])
        res_item['data'] = {"number": f"{int(item['patient_capacity'])-tot_pt}/{item['patient_capacity']}",
                            "label": "Number Of Beds Available/Total"}
        data.append(res_item)
    return data


def get_doctors_details(query, db):
    data = []
    print(query)
    res = db.doctors.find(query).sort("patients", -1).limit(5)
    for item in res:
        res_item = {}
        item.pop("_id")
        res_item["name"] = {"name": item["name"], "location": item["location"]}
        res_item['departments'] = {"departments": len(item['Working_days']), "label": "Working Days"}
        res_item['data'] = {"number": item['patients'], "label": "Number Of Patients:"}
        data.append(res_item)
    return data


def get_bar_graph(db, query=None):
    if query:
        pipe = [{'$match': query}, {'$group': {'_id': '$patient_in_date', 'total': {'$sum': 1}}}]
    else:
        pipe = [{'$group': {'_id': '$patient_in_date', 'total': {'$sum': 1}}}]
    res = db.patients.aggregate(pipeline=pipe)
    bar_result = {
        "labels": [
        ],
        "datasets": [
            {
                "label": "Patients In",
                "backgroundColor": "rgba(0, 158, 251, 0.5)",
                "borderColor": "rgba(0, 158, 251, 1)",
                "borderWidth": 1,
                "data": [

                ]
            }
        ]
    }
    line_result = {
        "labels": [

        ],
        "datasets": [
            {
                "label": "Total Patients",
                "backgroundColor": "rgba(0, 158, 251, 0.5)",
                "data": [

                ]
            }
        ]
    }
    bar_out = {}
    data = []
    for cur in res:
        data.append({"id": cur["_id"], "total": cur["total"]})
    data.sort(key=lambda x: datetime.strptime(x['id'], "%m/%d/%Y"))
    for item in data:
        month = datetime.strptime(item["id"], "%m/%d/%Y").strftime('%B')
        line_result['labels'].append(item["id"])
        line_result['datasets'][0]['data'].append(item["total"])
        if month not in bar_out:
            bar_out[month] = item['total']
        else:
            bar_out[month] += item['total']
    for key in bar_out.keys():
        bar_result['labels'].append(key)
        bar_result['datasets'][0]['data'].append(bar_out[key])
    return bar_result, line_result