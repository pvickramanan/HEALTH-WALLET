__author__ = "ajeesh"

import json
import logging
import re
from datetime import datetime
from this import d
from utils import dbutil, utils, models
import uuid
limit = 4


def create_appointment(request):
    db = dbutil.create_client()
    data = {"result": []}
    res = []
    input_json = json.loads(request.get_data())
    print(input_json)
    search_result = db.appointment.find({"patient_email": input_json.get("patient_email"), "active": True})
    res = list(search_result)
    if len(res) >= limit:
        return {"status": True, "message": f"Patient Already Having {limit} Open Appointments"}
    else:

        input_json['id'] = str(uuid.uuid4()).replace("-", "")
        res = db.appointment.insert_one(input_json)

        return {"status": True, "appointmentId": input_json['id']}


def get_appointment(request):
    db = dbutil.create_client()
    data = {"result": []}
    res = []
    input_json = json.loads(request.get_data())
    print({"patient_email": input_json.get("username")})
    hs_res = []
    if input_json.get("role", "") == "hospital":
        hosp_res = db.hospitals.find_one({"email": input_json.get("username")})
        hs_res = db.appointment.find({"hospital_id": hosp_res.get("id"), "active": True})
    elif input_json.get("role", "") == "doctor":
        doc_res = db.doctors.find_one({"email": input_json.get("username")})
        # current_date = datetime.now().strftime('%d/%m/%Y')
        # hs_res = db.appointment.find({"doctor_id": doc_res.get("id"), "date": current_date, "active": True})
        hs_res = db.appointment.find({"doctor_id": doc_res.get("id"), "active": True})
    elif input_json.get("role", "") == "patient":
        hs_res = db.appointment.find({"patient_email": input_json.get("username"), "active": True})
    else:
        hs_res = db.appointment.find({"active": True})
    if hs_res:
        for item in hs_res:
            hs_res = db.hospitals.find_one({"id": item.get("hospital_id")})
            hs_res.pop("_id")
            item['hospital_details'] = hs_res
            print("item")
            item.pop("_id")
            res.append(item)

    return {"status": True, "result": res}


def update_appointment(request):
    db = dbutil.create_client()
    input_json = json.loads(request.get_data())
    update_data = {
        "hospital_id": input_json.get("hospital_id"),
        "department": input_json.get("department"),
        "doctor_name": input_json.get("doctor_name"),
        "doctor_id": input_json.get("doctor_id"),
        "date": input_json.get("date"),
        "time": input_json.get("time"),
        "message": input_json.get("message")
    }
    db.appointment.update_one({"id": input_json.get("id")}, {"$set": update_data})
    return {"status": True, "message": "Appointment Details Updated for " + input_json.get("id"),
            'appointmentId': input_json.get("id")}


def delete_appointment(request):
    db = dbutil.create_client()
    input_json = json.loads(request.get_data())
    db.appointment.delete_one({"id":input_json.get("id")})
    return {"status": True, "message": "Deleted "+input_json.get("id")}


def consult_appointment(request):
    db = dbutil.create_client()
    input_json = json.loads(request.get_data())
    res = db.appointment.find_one({"id": input_json.get("id")})
    data = {}
    if res:
        res.pop("_id")
        data = res
        pt_res = db.patients.find_one({"email": res['patient_email']})
        pt_res.pop("_id")
        pt_res['age'] = utils.calculate_age(pt_res['date_of_birth'])
        data['patient_details'] = pt_res
        hs_res = db.hospitals.find_one({"id": res["hospital_id"]})
        hs_res.pop("_id")
        data['hospital_details'] = hs_res
        lab_res = [item for item in db.labtests.find({}) if item.pop('_id')]
        data['lab_details'] = lab_res
        lab_result = db.labtests.distinct("specimen")
        if "—" in lab_result:
            lab_result.remove("—")
        data["specimen"] = lab_result
        disease_result = [item for item in db.diseases.find({"departments": res['department']}) if item.pop('_id')]
        data["diseases"] = disease_result
        symptoms_result = [item for item in db.symptoms.find() if item.pop('_id')]
        data["disease_name"] = symptoms_result
    return data


def add_prescription(request):
    db = dbutil.create_client()
    input_json = json.loads(request.get_data())
    if not input_json.get('active'):
        input_json['id'] = str(uuid.uuid4()).replace("-", "")
        db.appointment.insert_one(input_json)

    search_result = db.appointment.find_one({"id": input_json.get("id")})
    patient_detail = db.patients.find_one({"email": search_result["patient_email"]})
    db.appointment.update_one({"id": input_json.get("id")},
                              {"$set": {"prescription": input_json.get("prescription"),
                                        "active": False}})
    try:
        db.hospitals.update_one({"id": patient_detail.get("hospital_id")},
                                {"$inc": {"departments."+patient_detail["department"]+".patients": -1}})
        logging.info("departments."+patient_detail["department"]+".patients")

        db.hospitals.update_one({"id": search_result.get("hospital_id")},
                                {"$inc": {"departments."+input_json["department"]+".patients": 1}})
    except:
        pass

    logging.info("departments."+input_json["department"]+".patients")
    hs_name = db.hospitals.find_one({'id': search_result["hospital_id"]}).get('name')
    db.patients.update_one({"email": search_result["patient_email"]},
                           {"$set": {"doctor_id": search_result["doctor_id"],
                                     "hospital_id": search_result["hospital_id"],
                                     "hospital_name": hs_name,
                                     "department": search_result["department"],
                                     "condition": input_json.get("condition")}})
    try:
        db.diseases.update_one({"name": patient_detail["condition"]},
                               {"$inc": {"patient": -1}})
    except:
        pass
    db.diseases.update_one({"name": input_json.get("condition")},
                           {"$inc": {"patient": 1}})

    return {"status": True, "message": input_json.get("id")}


# Get Medical history from appointment index ie: data with active as false
def get_medical_history(request):
    db = dbutil.create_client()
    data = []
    input_json = models.request_params(request)
    if input_json.get("action", "") == "add":
        res = db.hospitals.find({})
        data = {"hospitals": []}
        for item in res:
            item.pop("_id")
            data["hospitals"].append(item)
        pt_res = db.patients.find_one({"email": input_json['username']})
        pt_res.pop("_id")
        pt_res['age'] = utils.calculate_age(pt_res['date_of_birth'])
        data['patient_details'] = pt_res
        lab_res = [item for item in db.labtests.find({}) if item.pop('_id')]
        data['lab_details'] = lab_res
        lab_result = db.labtests.distinct("specimen")
        if "—" in lab_result:
            lab_result.remove("—")
        data["specimen"] = lab_result
        disease_result = [item for item in db.diseases.find() if item.pop('_id')]
        data["diseases"] = disease_result
        symptoms_result = [item for item in db.symptoms.find() if item.pop('_id')]
        data["disease_name"] = symptoms_result
    elif input_json.get("role", "") == "patient":
        hs_res = db.appointment.find({"patient_email": input_json.get("username"), "active": False})
        if hs_res:
            for item in hs_res:
                print("item")
                item.pop("_id")
                hs_res = db.hospitals.find_one({"id": item["hospital_id"]})
                hs_res.pop("_id")
                item['hospital_details'] = hs_res

                pt_res = db.patients.find_one({"email": item['patient_email']})
                pt_res.pop("_id")
                pt_res['age'] = utils.calculate_age(pt_res['date_of_birth'])
                item['patient_details'] = pt_res

                data.append(item)
    else:
        return {"status": False, "message": "you don't have permission"}
    return {"status": True, "result": data}


def hospital_appointment(request):
    db = dbutil.create_client()
    data = {"result": []}
    res = []
    input_json = json.loads(request.get_data())
    hs_res = db.hospitals.find_one({"email": input_json.get("username")})
    if hs_res:
        hs_res.pop("_id")
        data['hospital_details'] = hs_res
        hospital_id = hs_res.get("id")
        res = db.patients.find({"hospital_id": hospital_id})
    for item in res:
        item.pop("_id")
        item['age'] = utils.calculate_age(item['date_of_birth'])
        data["result"].append(item)
    return data
