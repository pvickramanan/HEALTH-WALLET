__author__ = "Ajeesh"

import datetime
import json
import uuid
from utils import dbutil


# checks if e-mail id already exists or not during new patient sign-up
def signup_validation_service(request):
    db = dbutil.create_client()
    input_json = json.loads(request.get_data())
    email_result = db.patients.find_one({"email": input_json.get("email_id")})
    if email_result:
        return {"success": False, "message": "E-mail ID already exists"}
    else:
        return {"success": True, "message": "success"}


# User registration function for creating a new user
def register_user(request):
    try:
        db = dbutil.create_client()
        input_json = json.loads(request.get_data())
        input_json['id'] = str(uuid.uuid4()).replace("-", "")
        input_json['patient_in_date'] = datetime.datetime.today().strftime("%m/%d/%Y")
        db.patients.insert_one(input_json)
        login_dicts = {"id": input_json['id'], "username": input_json['user_name'], "email": input_json['email'],
                       "role": "patient", "password": "patient", "name": input_json['name']}
        db.login.insert_one(login_dicts)
        return {"success": True, "message": "success"}
    except Exception as e:
        return {"success": False, "message": str(e)}


def submit_feedback(request):
    try:
        db = dbutil.create_client()
        input_json = json.loads(request.get_data())
        input_json['id'] = str(uuid.uuid4()).replace("-", "")
        input_json['date'] = datetime.datetime.today().strftime("%m/%d/%Y")
        db.feedback.insert_one(input_json)
        return {"success": True, "message": "success"}
    except Exception as e:
        return {"success": False, "message": str(e)}
