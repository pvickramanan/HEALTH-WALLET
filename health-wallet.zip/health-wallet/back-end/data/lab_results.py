import body as body
import scrapy
import requests
from requests import head
from scrapy.selector import Selector
from scrapy.http import HtmlResponse

response  = requests.get('https://www.msdmanuals.com/professional/resources/normal-laboratory-values/blood-tests-normal-values')
print (response.url)
response.selector.xpath('//span/text()').get()
# a=response.xpath('//div[@class="tableWrapper"]/table/tbody/tr')
# print (a)
# response = fetch("https://www.msdmanuals.com/professional/resources/normal-laboratory-values/blood-tests-normal-values")
# response = HtmlResponse(url = 'https://www.msdmanuals.com/professional/resources/normal-laboratory-values/blood-tests-normal-values', body = body)
# response.xpassh shell "th('//title/text()').extract()
