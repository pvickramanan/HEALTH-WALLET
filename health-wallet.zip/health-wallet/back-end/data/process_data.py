__author__ = "ajeesh"

import datetime
import json
import re
import csv
import uuid
import random
import logging
from pymongo import MongoClient
from faker import Faker

fake = Faker()

# Creating a pymongo client
client = MongoClient('localhost', 27017)
db = client['hospital']

wk_days = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]

diseases = {}
departments = ["cardiology", "chiropody", "ENT", "dietetics", "general", "genetics", "geriatrics", "gynaecology",
               "immunology", "oncology", "orthopaedics", "paediatrics", ]
# departments = ["cardiology", "chiropody", "dentistry", "dietetics", "embryology", "endocrinology", "ENT",
# "gastroenterology", "general", "genetics", "geriatrics", "gynaecology", "hematology", "immunology", "neurology",
# "nutrition", "oncology", "orthopaedics", "paediatrics", "proctology", "rheumatology", "urology"]
dep_map = {
    "cardiology": ["coronary heart disease", "cerebrovascular disease", "peripheral arterial disease",
                   "rheumatic heart disease", "congenital heart disease", "deep vein thrombosis and pulmonary embolism",
                   'Covid 19'],
    "chiropody": ["plantar fasciitis", "bunions", "ingrown toenails", "flat feet", "calluses", "corns", "warts",
                  'Covid 19'],
    "dentistry": ["Bad Breath", "Tooth Decay", "Gum (Periodontal) Disease", "Mouth Sores", "Tooth Erosion",
                  'Tooth Sensitivity', "Toothaches and Dental Emergencies", 'Unattractive Smile', 'Covid 19'],
    "dietetics": ["Anaemia", "Cardiovascular", "Chronic Fatigue", "Food Allergies & Intolerance", 'Metabolic Detoxing',
                  'Gastrointestinal Disorders', 'Osteoporosis', 'Paediatrics & Teenage Nutrition', 'Covid 19'],
    "embryology": ["Embryo Transfer", "Cryopreservation", 'Covid 19'],
    "endocrinology": ["Diabetes mellitus", 'Thyroid dysfunction', 'Adiposity-Based Chronic DiseaseOsteoporosis',
                      'Adrenal disorder', "Lipid disorders", 'Metabolic abnormalities', "Growth disorders",
                      'Sexual function and reproduction', 'Covid 19'],
    "ENT": ["autoimmune inner ear disease", "Bell's Palsy", "cholesteatomas", "cochlear/acoustic nerve disorder",
            'conductive hearing loss',
            "congenital malformations", 'diseases of the parathyroid glands', 'diseases of the thyroid glands',
            "Endolymphatic hydrops",
            "eustachian tube dysfunction", "goiter (enlarged thyroid)", "Graves’ Disease", "Hashimoto’s Thyroiditis",
            "head and neck cancer", "hearing loss", "hyperacusis (sensitivity to everyday sounds)", "labyrinthitis",
            "laryngeal (voice box) tumors", "Meniere’s disease", "neck masses", "otitis externa (swimmer’s ear)",
            "otitis media (chronic ear infection/pain)", "otosclerosis", "para thyroidectomy", "parotidectomy",
            "perforated eardrum", "salivary gland disease", "sensorineural hearing loss", "sinus disorders",
            "submandibular gland for infection or tumor", "thyroid cancer", "thyroid nodules", "thyroidectomy",
            "tinnitus (ringing in the ear)", "TMJ (temporomandibular joint dysfunction)", "tonsillitis",
            "tympanic perforations", "vertigo (dizziness)", "vocal cord paralysis"],
    "gastroenterology": ["Gastrointestinal Cancer", "Liver Cancer", "Pancreatic Cancer", "Colorectal Cancer",
                         "Irritable Bowel Syndrome (IBS)", "Celiac Disease.", "Inflammatory Bowel Disease.",
                         "Gallbladder Disease.", "GERD (Heartburn, Acid Reflux)", "Hemorrhoids", 'Covid 19'],
    "general": ["Hypertension", "Ischaemic heart disease", "Asthma",
                "Emphysema or chronic obstructive pulmonary disease (COPD)", "Pneumonia", "Lung fibrosis",
                "Gastroenteritis", "Liver disease", "Cerebrovascular accident", "Epilepsy", "Dementia", "Anaemia",
                "Diabetes", "Thyroid disease", "Pituitary disease", 'Covid 19'],
    "genetics": ["spina bifida", "cleft lip", 'muscular dystrophy', "haemophilia", "high cholesterol",
                 'cystic fibrosis', 'Covid 19'],
    "geriatrics": ["Bladder Control Problems", 'Delirium', 'Dementia', "Osteoporosis", 'Covid 19'],
    "gynaecology": ["Adenomyosis", "Adnexal tumors", "Amniotic band syndrome", "Anterior prolapse (cystocele)",
                    "Asherman syndrome (intrauterine adhesions)", "Atypical isoimmunization", "Bacterial vaginosis",
                    "Bladder outlet obstruction", "Bleeding during pregnancy", "Cancer during pregnancy",
                    "Cervical cancer", "Cervical dysplasia", "Chronic pelvic pain in women",
                    "Congenital cystic adenomatoid malformation (CCAM)", "Congenital diaphragmatic hernia (CDH)",
                    "Congenital high airway obstruction syndrome (CHAOS)", "Conjoined twins", "Diaphragmatic hernia",
                    "Double uterus", "Ectopic pregnancy", "Endometrial cancer", "Endometriosis",
                    "Fallopian tube cancer", "Fecal incontinence", "Female infertility", "Female sexual dysfunction",
                    "Fetal anemia", "Fetal heart disease", "Fetal macrosomia", "Germ cell tumors",
                    "Gestational diabetes", "Heart disease in pregnancy", "High blood pressure (hypertension)",
                    "Hirsutism", "HPV infection", "Imperforate hymen", "Infertility", "Lichen planus",
                    "Lichen sclerosus", "Lower genital tract dysplasia", "Mediastinal teratoma", "Menopause",
                    "Menorrhagia (heavy menstrual bleeding)", "Menstrual cramps", "Miscarriage", "Mullerian anomalies",
                    "Multiple gestation", "Ovarian cancer", "Ovarian cysts", "Ovarian remnant syndrome",
                    "Overactive bladder", "Painful intercourse (dyspareunia)", "Pediatric neck masses",
                    "Pelvic organ prolapse", "Perimenopause", "Peritoneal cancer", "Placenta accreta",
                    "Placenta previa", "Polycystic ovary syndrome (PCOS)", "Posterior vaginal prolapse (rectocele)",
                    "Post-hysterectomy prolapse", "Postmenopausal bleeding", "Preeclampsia", "Pregestational diabetes",
                    "Pregnancy", "Pregnancy after transplant", "Premature birth", "Preterm labor",
                    "Primary ovarian insufficiency", "Pulmonary sequestration", "Rectovaginal fistula",
                    "Recurrent miscarriage", "Rh disease", "Rupture of membranes", "Sacrococcygeal teratoma (SCT)",
                    "Septate uterus", "Sexually transmitted diseases (STDs)", "Small bowel prolapse (enterocele)",
                    "Spina bifida", "Stress incontinence", "Thrombophilia", "Transvaginal mesh complications",
                    "Twin anemia-polycythemia sequence (TAPS)", "Twin reversed arterial perfusion (TRAP) sequence",
                    "Twin-to-twin transfusion syndrome (TTTS)", "Urethral diverticulum", "Urge incontinence",
                    "Urinary incontinence", "Uterine anomalies", "Uterine fibroids", "Uterine polyps",
                    "Uterine prolapse", "Vaginal agenesis", "Vaginal atrophy", "Vaginal bleeding", "Vaginal cancer",
                    "Vaginal fistula", "Vaginal septum", "Vaginitis", "Vesicovaginal fistula", "Vulvar cancer",
                    "Vulvar dysplasia", "Vulvodynia", "Yeast infection (vaginal)", 'Covid 19'],
    "hematology": ["anemia", "hemophilia", "blood clots", "leukemia", "lymphoma", "myeloma", 'Covid 19'],
    "immunology": ["asthma", 'sinusitis', 'occupational lung disease', "allergic rhinitis", 'hay fever', "eczema",
                   "contact dermatitis", "Gastrointestinal disorders", "multiple sclerosis", "lupus", 'bone marrow',
                   "organ transplants", 'gene therapy', 'Covid 19'],
    "neurology": ["Headaches", "Epilepsy", "Seizures", 'Stroke', "Amyotrophic Lateral Sclerosis", "Alzheimer's Disease",
                  "Dementia", "Parkinson's Disease", 'Covid 19'],
    "nutrition": ["High cholesterol", "Lactose intolerance", "Gluten intolerance", "Blood glucose control",
                  'Oral mucositis', "Dialysis", "ADHD", 'Covid 19'],
    "oncology": ["Bladder cancers", "kidney cancers", "genitourinary cancers", "Brain tumors", "Breast cancer",
                 "Cervical cancers", "ovarian cancers", "uterine cancers", "gynecologic cancers", "Colorectal cancers",
                 "stomach cancers", "pancreatic cancers", "gastrointestinal cancers", "Leukemia ", "blood cancers",
                 "Lung cancer", "Oral cancers", "esophageal cancers", "thyroid cancers", "head and neck cancers",
                 "Prostate and testicular cancer", "Skin cancer", 'Covid 19'],
    "orthopaedics": ["Bone deformities", "Bone infections", "Bone tumors", "Fractures", "amputation", "Malunion",
                     "Spinal deformities", 'Covid 19'],
    "paediatrics": ["Anxiety", "Attention-Deficit/Hyperactivity Disorder (ADHD)", "Autism Spectrum Disorders",
                    "Cerebral Palsy", "Conduct Disorder (CD)", "Depression", "Developmental Disabilities",
                    "Fetal Alcohol Spectrum Disorders", "Fragile X Syndrome", "Hearing Loss", "Hemophilia",
                    "Intellectual Disability", "Jaundice & Kernicterus", "Language Disorders", "Learning Disorders",
                    "Muscular Dystrophy", "Oppositional Defiant Disorder (ODD)", "Obsessive-Compulsive Disorder (OCD)",
                    "Post-traumatic Stress Disorder (PTSD)", "Sickle Cell Disease", "Spina Bifida", "Tourette Syndrome",
                    "Vision Loss"],
    "proctology": ["Abscesses  ", "fistulae", "Anal skin tags", "Colon and rectal cancer", "Diverticulitis", "Fissures",
                   "Hemorrhoids", "Inflammatory bowel disease (IBD)", "Irritable bowel syndrome (IBS)", "Polyps",
                   "Rectal prolaps", 'Covid 19'],
    "rheumatology": ["inflammatory joint disease", "rheumatoid arthritis", "degenerative joint disease",
                     "osteoarthritis", "autoimmune disease", "lupus", "back problems", "soft tissue disorders",
                     "tennis elbow", "metabolic bone disorders", "osteoporosis", "crystal arthropathies", "gout",
                     "musculoskeletal infections", 'Covid 19'],
    "urology": ["prostate cancer", "bladder cancer", "bladder prolapse", "hematuria", "erectile dysfunction (ED)",
                "interstitial cystitis", "overactive bladder", "prostatitis", 'Covid 19']

}
std_code = {
    "alappuzha": "477",
    "ernakulam": "484",
    "idukki": "4869",
    "kannur": "495",
    "kasargod": "4994",
    "kasaragod": "4994",
    "kollam": "474",
    "kottayam": "481",
    "kozhikode": "495",
    "malappuram": "4933",
    "palakkad": "491",
    "pathanamthitta": "468",
    "thrissur": "487",
    "thiruvananthapuram": "471",
    "wayanad": "4936"
}

qualification = ["MBBS", "MD", "MBBS,MS", "MS", "MBBS, MD", "HO", "BMBS, BM, MBChB", "MMedSc",
                 'DRCOG, DFFP, DRSH, CME', 'MRCGP/nMRCP', "MCM", "MMSc", 'MPH', "MM, MMed", "MPhil", "MBBS, DCM"]


def insert_data_for_login():
    # Getting the database instance
    logging.info("login")
    coll = db['login']
    doc1 = [
        {"id": str(uuid.uuid4()).replace("-", ""),
         "username": "admin",
         "email": "ajeesh@gmail.com",
         "role": "admin",
         "password": "123",
         "name": "Ajeesh"
         },
        {"id": str(uuid.uuid4()).replace("-", ""),
         "username": "ajeesh",
         "email": "ajeesh12@gmail.com",
         "role": "admin",
         "password": "123",
         "name": "Admin"
         }
    ]
    coll.insert_many(doc1)


def insert_data_for_bloodbank():
    # Creating a collection
    coll = db['bloodbank']

    # Inserting document into a collection
    # doc1 = {"name": "Ram", "age": "26", "city": "Hyderabad"}
    # coll.insert_one(doc1)
    # logging.info(coll.find_one())
    out_data = []

    with open('bloodbank.csv') as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        line_count = 0
        for row in csv_reader:
            logging.info(f'\t{row[0]} works in the {row[1]}.')
            nam = row[0].lower().split()
            email = re.sub("[^A-Za-z0-9.]", "", row[0]).lower() + "@gmail.com"
            if len(nam) > 4:
                if "email" in row[0].lower():
                    nam = re.sub("[^A-Za-z0-9.]", "", row[0]).lower().replace("district", "") + "@gmail.com"
                    if nam not in out_data:
                        out_data.append(nam)
                        email = nam
                    else:
                        out_data.append(email)
            doc1 = {"id": str(uuid.uuid4()).replace("-", ""),
                    "name": row[0], "location": row[1],
                    "email": email,
                    "A+ve": {"available": random.randint(0, 180), "capacity": 200},
                    "A-ve": {"available": random.randint(0, 30), "capacity": 100},
                    "O+ve": {"available": random.randint(0, 180), "capacity": 200},
                    "O-ve": {"available": random.randint(0, 30), "capacity": 100},
                    "AB+ve": {"available": random.randint(0, 170), "capacity": 200},
                    "AB-ve": {"available": random.randint(0, 45), "capacity": 100},
                    "B+ve": {"available": random.randint(0, 70), "capacity": 100},
                    "B-ve": {"available": random.randint(0, 80), "capacity": 100}
                    }
            coll.insert_one(doc1)
            line_count += 1
        logging.info(f'Processed {line_count} lines.')
        logging.info(out_data)


def insert_data_for_hospitals():
    # Creating a collection
    coll = db['hospitals']

    # Inserting document into a collection
    # doc1 = {"name": "Ram", "age": "26", "city": "Hyderabad"}
    # coll.insert_one(doc1)
    # logging.info(coll.find_one())

    out_data = []
    emails = []
    with open('hospital_details.csv') as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        line_count = 0

        doc_list = []
        pt_dicts = []
        login_dicts = []
        hosp_list = []
        count = 0
        for row in csv_reader:
            logging.info(f'\t{row[0]} works in the {row[1]}.')
            nam = row[0].lower().split()
            count += 1
            icu_beds = random.randint(30, 80)
            oxygen = random.randint(20, 60)
            bed_count = 1
            oxy_count = 1
            hosp_id = str(uuid.uuid4()).replace("-", "")
            email = re.sub("[^A-Za-z0-9.]", "", row[0]).lower() + "@gmail.com"
            rand_int = random.randint(1, len(departments) - 1)
            if len(nam) > 4:
                if "hospital" in row[0].lower():
                    nam = re.sub("[^A-Za-z0-9.]", "", row[0]).lower().replace("district", "") + "@gmail.com"
                    if nam not in out_data:
                        out_data.append(nam)
                        email = nam
                    else:
                        out_data.append(email)
            deps = {}
            rand_deps = random.sample(departments, rand_int)
            total = 0
            for department in rand_deps:
                rand_patients = random.randint(100, 200)
                deps[department] = {"patients": rand_patients, 'doctors': []}
                no_doc = random.randint(3, 8)
                tot_pt_c = 0
                logging.info(rand_patients)
                for i in range(no_doc):
                    name = fake.name()
                    address = fake.address()
                    doc_id = str(uuid.uuid4()).replace("-", "")
                    mail = fake.email()
                    while mail in emails:
                        mail = fake.email()
                    emails.append(mail)
                    pt_c = int(rand_patients / no_doc)
                    if i + 1 == rand_int:
                        pt_c = rand_patients - tot_pt_c
                    else:
                        tot_pt_c += pt_c
                    logging.info(pt_c)
                    deps[department]["doctors"].append({"name": name, "id": doc_id})
                    doc_qual = qualification[random.randint(0, len(qualification) - 1)]
                    doc_dic = {"name": name, "hospital_id": hosp_id, "hospital_name": row[0], "id": doc_id,
                               "date_of_birth": fake.date_of_birth(minimum_age=27, maximum_age=60).strftime("%m/%d/%Y"),
                               "address": address, "email": mail, "department": department, "working_hours": 8,
                               "Working_days": random.sample(wk_days, 3), "earned_leaves": 24,
                               "gender": ["Male", "Female"][random.randint(0, 1)], "qualification": doc_qual,
                               "leave_taken": random.randint(1, 20), "patients": pt_c, "location": row[2],
                               "district": row[1], "pincode": row[3], "phone": fake.phone_number()}
                    doc_list.append(doc_dic)
                    # db.doctors.insert_one(doc_dic)
                    login_dicts.append({"id": str(uuid.uuid4()).replace("-", ""), "username": mail, "email": mail,
                                        "role": "doctor", "password": "doctor", "name": name})
                    for i in range(pt_c):
                        ward = "General"
                        need_oxygen = "False"
                        if bed_count < icu_beds and i <= 3:
                            ward = "ICU"
                            bed_count += 1
                        if oxy_count < oxygen and i <= 3:
                            need_oxygen = "True"
                            oxy_count += 1
                        pt_name = fake.name()
                        pt_gender = ["Male", "Female"][random.randint(0, 1)]
                        pt_id = str(uuid.uuid4()).replace("-", "")
                        pt_email = fake.email()
                        pt_dob = fake.date_of_birth(minimum_age=10).strftime("%m/%d/%Y")
                        while pt_email in emails:
                            pt_email = fake.email()
                        emails.append(pt_email)
                        if department in ["gynaecology", 'embryology']:
                            pt_name = fake.name_female()
                            pt_gender = "Female"
                        if department == "paediatrics":
                            pt_dob = fake.date_of_birth(maximum_age=10).strftime("%m/%d/%Y")

                        condition = dep_map[department][random.randint(0, len(dep_map[department]) - 1)]
                        if condition not in diseases:
                            diseases[condition] = {"patient": 0, "hospitals": [], "doctors": [], "departments": []}
                        diseases[condition]['name'] = condition
                        diseases[condition]['patient'] += 1
                        if department not in diseases[condition]['departments']:
                            diseases[condition]['departments'].append(department)
                        if hosp_id not in diseases[condition]['hospitals']:
                            diseases[condition]['hospitals'].append(hosp_id)
                        if doc_id not in diseases[condition]['doctors']:
                            diseases[condition]['doctors'].append(doc_id)

                        pt_dic = {"name": pt_name, "hospital_id": hosp_id, "hospital_name": row[0], "doctor_id": doc_id, "id": pt_id,
                                  "address": fake.address(), "email": pt_email, "condition": condition,
                                  "department": department, "city": fake.city(), "date_of_birth": pt_dob,
                                  "history": [], "lab_results": [], "gender": pt_gender, "user_name": pt_email,
                                  "password": "123", "phone": fake.phone_number(), "ward": ward,
                                  "oxygen_need": need_oxygen, "patient_in_date": fake.date_between(
                                datetime.datetime.strptime('01/01/2021', "%m/%d/%Y"),
                                datetime.datetime.today()).strftime("%m/%d/%Y")}
                        # logging.info(pt_name)
                        pt_dicts.append(pt_dic)
                        login_dicts.append(
                            {"id": str(uuid.uuid4()).replace("-", ""), "username": pt_email, "email": pt_email,
                             "role": "patient", "password": "patient", "name": pt_name})
                total += rand_patients

            phone_number = std_code[row[1].lower()] + "-2" + str(random.randint(222222, 999999))
            doc1 = {"id": hosp_id, "name": row[0], "location": row[2], "district": row[1], "pincode": row[3],
                    "address": row[4], "email": email, "patient_capacity": total + 1000, "phone": phone_number,
                    "departments": deps, "oxygen_cylinders": oxygen, "icu_beds": icu_beds}
            # logging.info(row[0])
            login_dicts.append({"id": str(uuid.uuid4()).replace("-", ""), "username": email, "email": email,
                                "role": "hospital", "password": "hospital", "name": name})
            hosp_list.append(doc1)
            if count == 20:
                db.login.insert_many(login_dicts)
                db.patients.insert_many(pt_dicts)
                coll.insert_many(hosp_list)
                db.doctors.insert_many(doc_list)
                count = 0
                hosp_list = []
                doc_list = []
                pt_dicts = []
                login_dicts = []
                logging.info("added {} documents".format(count))
            # logging.info(doc1)
            # break
            line_count += 1
        db.login.insert_many(login_dicts)
        db.patients.insert_many(pt_dicts)
        coll.insert_many(hosp_list)
        db.doctors.insert_many(doc_list)
        try:
            for condition, values in diseases.items():
                doc_val = values
                doc_val['id'] = str(uuid.uuid4()).replace("-", "")
                doc_val['description'] = ""
                doc_val['tests'] = []
                db.diseases.insert_one(values)
        except:
            with open('disease_out.txt', 'w') as f:
                f.write(json.dumps(diseases))
            f.close()
        logging.info(f'Processed {line_count} lines.')


def insert_medicine():
    coll = db['medicine']
    with open('medicine.csv') as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        line_count = 0
        for row in csv_reader:
            logging.info(f'\t{row[0]}')
            print(f'\t{row[0]}')
            doc1 = {"id": str(uuid.uuid4()).replace("-", ""),
                    "name": row[0]}
            coll.insert_one(doc1)
            line_count += 1
        logging.info(f'Processed {line_count} lines.')


if __name__ == "__main__":
    logging.basicConfig(filename='logDetails.log', level=logging.INFO)
    logging.info('Started')
    logging.info("Loading data to db")
    insert_data_for_login()
    insert_data_for_bloodbank()
    insert_data_for_hospitals()
    insert_medicine()
