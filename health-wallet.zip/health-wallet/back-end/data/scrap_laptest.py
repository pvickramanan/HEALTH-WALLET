# Scripts to get all the lab tests available and its normal values
import json
from utils import dbutil, utils
import uuid
import scrapy
import requests
import string


urls = ["https://www.msdmanuals.com/professional/resources/normal-laboratory-values/other-tests-normal-values",
        "https://www.msdmanuals.com/professional/resources/normal-laboratory-values/urine-tests-normal-values",
        "https://www.msdmanuals.com/en-in/professional/resources/normal-laboratory-values/blood-tests-normal-values"]

db = dbutil.create_client()


def index_lab_details():
    coll = db['labtests']
    for url in urls:
        resp = requests.get(url)
        response = scrapy.Selector(text=resp.text)
        items = response.xpath('.//tbody/tr')
        for item in items:
            lab_test = {"id": str(uuid.uuid4()).replace("-", "")}
            if item.xpath('.//td')[0].xpath('.//ul'):
                continue
            lab_test["test"] = "".join(item.xpath('.//td')[0].xpath('./div//text()').getall()).strip()
            try:
                lab_test["specimen"] = "".join(item.xpath('.//td')[1].xpath('./div//text()').getall()).strip().split(',')[0]
            except Exception as e:
                continue
            if lab_test["specimen"] == "":
                continue
            lab_test["conventional_units"] = "".join(item.xpath('.//td')[2].xpath('./div//text()').getall()).strip()
            lab_test["si_units"] = "".join(item.xpath('.//td')[3].xpath('./div//text()').getall()).strip()
            coll.insert_one(lab_test)
            print(lab_test)


def index_disease():
    added_list = []
    exclude = ["About NHS inform", "Editorial policy", "Contact us", "Webchat", "Feedback", "Info for Me tool",
               "Terms and conditions", "Privacy and cookies policy", "Freedom of information (FOI)", "Accessibility", "Other languages and formats"]
    col = db['symptoms']
    disease_urls = ["https://www.nhsinform.scot/illnesses-and-conditions/a-to-z"]
    for url in disease_urls:
        resp = requests.get(url)
        response = scrapy.Selector(text=resp.text)
        items = response.css('ul.nhsuk-list li')
        for item in items:
            disease_name = item.xpath('./a/text()').get('').strip()
            if disease_name in exclude:
                continue
            if "language" in disease_name:
                continue
            if disease_name:
                print(disease_name)
                if disease_name not in added_list:
                    added_list.append(disease_name)
                    col.insert_one({"id": str(uuid.uuid4()).replace("-", ""), "disease_name": disease_name})

    az_upper = string.ascii_uppercase
    for i in az_upper:
        url = f"https://www.mayoclinic.org/symptoms/index?letter={i}"
        resp = requests.get(url)
        response = scrapy.Selector(text=resp.text)
        items = response.css('div.index ol li')
        for item in items:
            text = item.xpath('.//text()').getall()
            text = "".join(text).strip()
            if text in exclude:
                continue
            text = text.split('(')[0]
            if 'pain' in text.lower():
                text = text.lower()
                text = text.replace('pain,', 'pain')
            if 'high' in text or 'blood' in text:
                text = text.replace(',', '')
            if 'languages' in text:
                continue
            if ':' in text:
                text = text.split(':')[0]

            if "," in text:
                text = text.split(',')
                for text_item in text:
                    print(text_item.strip())
                    if text_item.strip() not in added_list:
                        added_list.append(text_item.strip())
                        col.insert_one({"id": str(uuid.uuid4()).replace("-", ""), "disease_name": text_item.strip()})
            else:
                print(text)
                if text not in added_list:
                    added_list.append(text)
                    col.insert_one({"id": str(uuid.uuid4()).replace("-", ""), "disease_name": text})


# print(json.dumps(tests))
if __name__ == "__main__":
    index_lab_details()
    index_disease()
