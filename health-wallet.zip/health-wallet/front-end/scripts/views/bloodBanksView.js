/**
 * Created by getit on 19-04-2017.
 */
 define(['datatables', 'select2','bootBox'], function() {
    var bloodBanksView = NeoBackboneView.extend({
        tagName: 'div',
        className: 'content',
        template : this.template = _.template($('#bloodbank_details_templates').html()),
        initialize: function (obj) {
            this.router = obj.router;
            this.parentView = obj.parentView;
            this.model = obj.data;
        },
        events: {
            "click .edit-blood-banks": "editBloodBankDetails",
            "click .add-bloodbank": "addBloodBank",
            "click .delete-blood-banks": "deleteBloodBank",
        },
        render: function () {
            var browseHtml = this.template({'data' : this.model, "abbreviateNumber": abbreviateNumber});
            this.$el.html(browseHtml);
            $('#page-content').html(this.$el);
            this.defaultScript();
            $('.datatable').DataTable({
                "bFilter": true,
            });
            if($('.select').length > 0) {
                $('.select').select2({
                    minimumResultsForSearch: -1,
                    width: '100%'
                });
            }
        },
        defaultScript : function () {

        },
        editBloodBankDetails : function (e) {
            var id = $(e.currentTarget).attr('data-id')
            var input = {
                'id': id
            }
            loadService("getBloodBankDetail",input,function (json) {
                var editBloodBankView = new editBloodBank({
                    "parent" : this,
                    "route" : this.router,
                    "data" : json.data
                })
                editBloodBankView.render();
            })
        },
        addBloodBank : function (e) {
            loadService('hospitalsDataLoad', "" , function(json){
                var uaserProfiel = new addBloodBank({
                    "parent" : this,
                    "route" : this.router,
                    "data": json.data
                })
                uaserProfiel.render();
            },function(){},"POST");
        },
        deleteBloodBank : function(e){
            var id = $(e.currentTarget).attr('data-id')
            var name = $(e.currentTarget).attr('data-name')
            var input = {
                'id': id
            }
            bootbox.confirm({
                title: "Confirm Blood Bank Deletion",
                message: "Remove " + name + " ?",
                className: 'alternate-modal',
                buttons: {
                    cancel: {
                        className: 'btn-sm',
                        label: '<i class="fa fa-times"></i> Cancel'
                    },
                    confirm: {
                        className: 'btn-sm btn-primary',
                        label: '<i class="fa fa-check"></i> Confirm'
                    }
                },
                callback: function (result) {
                    if (result) {
                        loadService('deleteBloodBank', input, function (json) {
                            if (json.status == 'success') {
                                $(e.currentTarget).parent().parent().parent().parent().fadeOut(500, function () {
                                    $(this).remove();
                                });
                            }
                        })
                    }
                }
            });
        }
        
    });
    var editBloodBank = NeoBackboneView.extend({
        template: this.template = _.template($('#bloodbank_edit_details_templates').html()),
        initialize: function (obj) {
            this.router = obj.router;
            this.parentView = obj.parentView;
            this.model = obj.data;
        },
        events: {
            "click .update-blood-details": "updateBloodBankDetails",
        },
        render: function () {
            var browseHtml = this.template({"data" : this.model});
            this.$el.html(browseHtml);
            $('#page-content').html(this.$el);
            $('.select').select2({
                minimumResultsForSearch: -1,
                width: '100%'
            });
        },
        updateBloodBankDetails : function (e) {
            var id = $(e.currentTarget).attr('data-id')
            var data = {
                'id': id,
                'name': $('.bld-name').val(),
                'email': $('.bld-email').val(),
                'location': $('.bld-location').val(),
                'phone': $('.bld-phone').val(),
                'A+ve': {
                    "available": $('.bld-a-positive-avb').val(),
                    "capacity": $('.bld-a-positive-cap').val()
                },
                'A-ve': {
                    "available": $('.bld-a-negative-avb').val(),
                    "capacity": $('.bld-a-negative-cap').val()
                },
                'B+ve': {
                    "available": $('.bld-b-positive-avb').val(),
                    "capacity": $('.bld-b-positive-cap').val()
                },
                'B-ve': {
                    "available": $('.bld-b-negative-avb').val(),
                    "capacity": $('.bld-b-negative-cap').val()
                },
                'AB+ve': {
                    "available": $('.bld-ab-positive-avb').val(),
                    "capacity": $('.bld-ab-positive-cap').val()
                },
                'AB-ve': {
                    "available": $('.bld-ab-negative-avb').val(),
                    "capacity": $('.bld-ab-negative-cap').val()
                },
                'O+ve': {
                    "available": $('.bld-o-positive-avb').val(),
                    "capacity": $('.bld-o-positive-cap').val()
                },
                'O-ve': {
                    "available": $('.bld-o-negative-avb').val(),
                    "capacity": $('.bld-o-negative-cap').val()
                },
            }
            console.log(data)
            var cv = this
            loadService("updateBloodBankDetail",data,function (json) {
                if (json.data.success === true){
                    $.notify('Updated successfully', 'success');
                    cv.renderbloodBanks()
                }else{
                    $.notify('Failed to Update Details', 'error');
                }
            })
        },
        renderbloodBanks : function () {
            $('#side-menu li.redirectTag').removeClass('active');
            // $('li[datakey=landingDashboard]').addClass('active');
            $(".redirectTag[dataKey='bloodBanks']").addClass('active');
            var self = this;
            loadService('bloodBanksDataLoad', "" , function(json){
                getTemplates('bloodBanks', 'bloodbank-details-templates', function() {
                    require(['views/bloodBanksView'], function(browsePageVw) {
                        var browsePageView = new browsePageVw({
                            "router" : self.router,
                            "parentView" : self,
                            "data" : json.data
                        });
                        self.currentPageTemplate = "bloodbank-details-templates";
                        self.currentPageView = browsePageView;
                        self.childViews.push(browsePageView);
                        browsePageView.render();
                    });
                });
            },function(){},"GET");
        },
    });
    var addBloodBank = NeoBackboneView.extend({
        template: this.template = _.template($('#bloodbank_add_templates').html()),
        initialize: function (obj) {
            this.router = obj.router;
            this.parentView = obj.parentView;
            this.model = obj.data
        },
        events: {
            "click .save-blood-details": "saveBloodBankDetails",
            "change .bld-name": "changeTitle"
        },
        render: function () {
            var browseHtml = this.template({"data" : this.model});
            this.$el.html(browseHtml);
            $('#page-content').html(this.$el);
            $('.select').select2({
                width: '100%',
                placeholder: "Please select a Hospital"
            });
        },
        saveBloodBankDetails : function (e) {
            var data = {
                'id': "",
                'name': $('.bld-name').val(),
                'email': $('.bld-email').val(),
                'location': $('.bld-location').val(),
                'phone': $('.bld-phone').val(),
                'A+ve': {
                    "available": $('.bld-a-pos-avb').val(),
                    "capacity": $('.bld-a-pos-cap').val()
                },
                'A-ve': {
                    "available": $('.bld-a-neg-avb').val(),
                    "capacity": $('.bld-a-neg-cap').val()
                },
                'B+ve': {
                    "available": $('.bld-b-pos-avb').val(),
                    "capacity": $('.bld-b-pos-cap').val()
                },
                'B-ve': {
                    "available": $('.bld-b-neg-avb').val(),
                    "capacity": $('.bld-b-neg-cap').val()
                },
                'AB+ve': {
                    "available": $('.bld-ab-pos-avb').val(),
                    "capacity": $('.bld-ab-pos-cap').val()
                },
                'AB-ve': {
                    "available": $('.bld-ab-neg-avb').val(),
                    "capacity": $('.bld-ab-neg-cap').val()
                },
                'O+ve': {
                    "available": $('.bld-o-pos-avb').val(),
                    "capacity": $('.bld-o-pos-cap').val()
                },
                'O-ve': {
                    "available": $('.bld-o-neg-avb').val(),
                    "capacity": $('.bld-o-neg-cap').val()
                },
            }
            console.log(data)
            var cv = this
            if ($('.bld-name').val() && $('.bld-email').val()){
                loadService("saveBloodBankDetail",data,function (json) {
                    if (json.data.success === true){
                        $.notify('Added successfully', 'success');
                        cv.renderbloodBanks()
                    }else{
                        $.notify('Failed to Add Details', 'error');
                    }
                })
            }
            
        },
        changeTitle: function() {
            var name = $('.bld-name').val()
            $.each(this.model.result, function(ind,val){
                if (val.name == name){
                    console.log(val)
                    $('.bld-email').val(val.email)
                    $('.bld-location').val(val.location)
                    $('.bld-phone').val(val.phone)
                }
            })
        },
        renderbloodBanks : function () {
            $('#side-menu li.redirectTag').removeClass('active');
            // $('li[datakey=landingDashboard]').addClass('active');
            $(".redirectTag[dataKey='bloodBanks']").addClass('active');
            var self = this;
            loadService('bloodBanksDataLoad', "" , function(json){
                getTemplates('bloodBanks', 'bloodbank-details-templates', function() {
                    require(['views/bloodBanksView'], function(browsePageVw) {
                        var browsePageView = new browsePageVw({
                            "router" : self.router,
                            "parentView" : self,
                            "data" : json.data
                        });
                        self.currentPageTemplate = "bloodbank-details-templates";
                        self.currentPageView = browsePageView;
                        self.childViews.push(browsePageView);
                        browsePageView.render();
                    });
                });
            },function(){},"GET");
        },
    });
    return bloodBanksView;
});