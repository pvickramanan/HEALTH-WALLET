/**
 * Created by getit on 19-04-2017.
 */
 define(['datatables'], function() {
    var profileView = NeoBackboneView.extend({
        tagName: 'div',
        className: 'content',
        template : this.template = _.template($('#profile_management_template').html()),
        initialize: function (obj) {
            this.router = obj.router;
            this.parentView = obj.parentView;
            this.model = obj.data;
        },
        events: {
            "click .edit-profile": "editProfile"
        },
        render: function () {
            var role = localStorage.getItem('session_userRole')
            var browseHtml = this.template({'data' : this.model.result, 'role': role});
            this.$el.html(browseHtml);
            $('#page-content').html(this.$el);
            $('.datatable').DataTable({
                "bFilter": false,
            });
        },
        editProfile : function () {
            var cv = this
            var editProfilePopup = new editAppointmentData({
                "parent" : cv,
                "route" : cv.router,
                "data": cv.model
            })
            editProfilePopup.render();
        }
    });

    var editAppointmentData = NeoBackboneView.extend({
        tagName: 'div',
        className: 'content',
        template: this.template = _.template($('#edit_profile_templates_'+localStorage.getItem('session_userRole')).html()),
        initialize: function (obj) {
            this.router = obj.router;
            this.parentView = obj.parentView;
            this.model = obj.data;
        },
        events: {
            "click .update-profile": 'updateProfile',
        },
        render: function () {
            cv = this
            var browseHtml = this.template({"data" : this.model});
            this.$el.html(browseHtml);
            $('#page-content').html(this.$el);
            $('.datetimepicker').datetimepicker({
                maxDate:new Date(),
                format: 'MM/DD/YYYY'
            });
            $('.datetimepicker').val(cv.model.result.date_of_birth)
            $('input[value="'+cv.model.result.gender+'"]').prop("checked", true);
        },
        updateProfile: function() {
            var cv = this
            const role = localStorage.getItem('session_userRole');
            var name = $('.userfname').val();
            var dob = $('.userdob').val();
            var gender = $('input[name="gender"]:checked').val();
            var address = $('.useraddress').val();
            var city = $('.city-name').val();
            var phone = $('.userphone').val();
            var username = localStorage.getItem('session_logname')

            
            var qual = $('.qualification').val();
            var pincode = $('.pincode').val();
            var district = $('.district').val();
            var icu_beds = $('.icu-beds').val();
            var patient_capacity = $('.patient-capacity').val();
            var oxygen_cylinders = $('.oxygen-cylinders').val();
            let valid = false
            let input_data = {}
            if (role === 'patient'){
                if(name && dob && gender && address && city && phone){
                    valid = true
                }
                input_data = {
                    'name': name, 'date_of_birth': dob, 'gender': gender, 'address': address, 'phone': phone,
                    'city': city,'username': username, "role": role,
                }
            }else if (role === 'doctor'){
                if(name && dob && gender && address && qual && phone && pincode && district){
                    valid = true
                }
                input_data = {
                    'name': name, 'date_of_birth': dob, 'gender': gender, 'address': address, 'phone': phone, 'qualification': qual,
                    'pincode': pincode,'username': username, "role": role, 'district': district
                }
            }else if (role === "hospital"){
                if(name && address && pincode && phone && district && icu_beds && oxygen_cylinders && patient_capacity){
                    valid = true
                }
                input_data = {
                    'name': name, 'address': address, 'phone': phone, 'pincode': pincode,'username': username, "role": role, 
                    'district': district, 'icu_beds': icu_beds, 'oxygen_cylinders': oxygen_cylinders, 'patient_capacity': patient_capacity
                }
            }
            if (valid){
                loadService('profileDetails',input_data,function (json) {
                    if(json.data.success){
                        $.notify("Successfully updated", 'success');
                        cv.renderprofileDetails()
                    }else {
                        $.notify("Profile updation Failed, Contact Admin", 'error');
                    }
                },function(){},"PUT")
            }else{
                $.notify("All fields are required, Please fill", 'error');
            }
        }, 
        renderprofileDetails : function () {
            var input_json = {
                "role": localStorage.getItem('session_userRole'),
                "username": localStorage.getItem('session_userId'),
            }
            $('#side-menu li.redirectTag').removeClass('active');
            // $('li[datakey=landingDashboard]').addClass('active');
            $(".redirectTag[dataKey='profileDetails']").addClass('active');
            var self = this;
            loadService('profileDetails', input_json , function(json){
                getTemplates('profile', 'profile-details-templates', function() {
                    require(['views/profileView'], function(browsePageVw) {
                        var browsePageView = new browsePageVw({
                            "router" : self.router,
                            "parentView" : self,
                            "data" : json.data
                        });
                        self.currentPageTemplate = "profile-details-templates";
                        self.currentPageView = browsePageView;
                        self.childViews.push(browsePageView);
                        browsePageView.render();
                    });
                });
            },function(){},"POST");
        },
    });
    return profileView;
});