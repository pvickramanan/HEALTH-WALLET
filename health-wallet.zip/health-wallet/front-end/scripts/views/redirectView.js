define(['notify', 'chart', 'bundle'], function() {
	var redirectView = NeoBackboneView.extend({
        tagName : 'div',
        className : 'content',
		template : this.template = _.template($('#landingTemplate').html()),
		initialize : function(obj) {
			this.router = obj.router;
			this.model = obj.data;
			this.currentPageTemplate = undefined;
			this.currentPageView;
		},
		events : {
            "click .redirectTag" : "redirectPage",
		},
		render : function() {
			var browseHtml = this.template(this.model);
			this.$el.html(browseHtml);
			$('#wrapper').html(this.$el);
            this.defaultScript();
		},
    
        defaultScript : function () {
            $('.navbar-minimalize').click(function () {
                $("body").toggleClass("mini-navbar");
                SmoothlyMenu();
            });
            $('#sidebar-menu a').on('click', function(e) {
                if($(this).parent().hasClass('submenu')) {
                    e.preventDefault();
                }
                if(!$(this).hasClass('subdrop')) {
                    $('ul', $(this).parents('ul:first')).slideUp(350);
                    $('a', $(this).parents('ul:first')).removeClass('subdrop');
                    $(this).next('ul').slideDown(350);
                    $(this).addClass('subdrop');
                } else if($(this).hasClass('subdrop')) {
                    $(this).removeClass('subdrop');
                    $(this).next('ul').slideUp(350);
                }
            });
            $('#sidebar-menu ul li.submenu a.active').parents('li:last').children('a:first').addClass('active').trigger('click');
        },
        redirectPage : function (e) {
            var self = this;
            $('#sidebar-menu li.redirectTag').removeClass('active');
            $(e.currentTarget).addClass('active');
            var role = localStorage.getItem('session_userRole')
            var pageKey = $(e.currentTarget).attr('dataKey');
            if(pageKey == 'adminDashboard' && (role === "admin" || role === "hospital")){
                // self.renderDashboard();
                window.location.href = "#Dashboard"
            }else if(pageKey == 'diseaseDetails'){
                // self.renderDashboard();
                window.location.href = "#diseaseMangement"
            }else if(pageKey == 'hospitalsDetails' && role === "admin"){
                // self.renderUserManagement();
                window.location.href = "#hospitalsDetails"
            }else if(pageKey == 'bloodBanks' && role === "admin"){
                // self.renderUserManagement();
                window.location.href = "#bloodBanks"
            }else if(pageKey == 'laboratoriesDetails'){
                // self.renderUserManagement();
                window.location.href = "#laboratoriesDetails"
            }else if(pageKey == 'doctorsDetails'){
                // self.renderUserManagement();
                window.location.href = "#doctorsDetails"
            }else if(pageKey == 'patientsDetails'){
                // self.renderUserManagement();
                window.location.href = "#patientsDetails"
            }else if(pageKey == 'profileDetails'){
                // self.renderUserManagement();
                window.location.href = "#profileDetails"
            }else if(pageKey == 'changePassword'){
                // self.renderUserManagement();
                window.location.href = "#changePassword"
            }else if(pageKey == 'appointments'){
                // self.renderUserManagement();
                window.location.href = "#appointmentDetails"
            }else if(pageKey == 'medicalHistory'){
                // self.renderUserManagement();
                window.location.href = "#medicalHistory"
            }else if(pageKey == 'feedback'){
                window.location.href = "#feedback"
            }
        },
        renderDashboard : function () {
            var input_json = {
                "role": localStorage.getItem('session_userRole'),
                "username": localStorage.getItem('session_userId'),
            }
            $('#side-menu li.redirectTag').removeClass('active');
            // $('li[datakey=landingDashboard]').addClass('active');
            $(".redirectTag[dataKey='adminDashboard']").addClass('active');
            var self = this;
            loadService('DashboardLoad', input_json , function(json){
                getTemplates('dashboardAdmin', 'dashboard-admin-templates', function() {
                    require(['views/dashboardViewAdmin'], function(browsePageVw) {
                        var browsePageView = new browsePageVw({
                            "router" : self.router,
                            "parentView" : self,
                            "data" : json.data
                        });
                        self.currentPageTemplate = "dashboard-admin-templates";
                        self.currentPageView = browsePageView;
                        self.childViews.push(browsePageView);
                        browsePageView.render();
                    });
                });
            },function(){},"POST");
        },
        renderdiseaseMangement : function () {
            var input_json = {
                "role": localStorage.getItem('session_userRole'),
                "username": localStorage.getItem('session_userId'),
            }
            $('#side-menu li.redirectTag').removeClass('active');
            // $('li[datakey=landingDashboard]').addClass('active');
            $(".redirectTag[dataKey='diseaseDetails']").addClass('active');
            var self = this;
            loadService('diseaseDetails', input_json , function(json){
                getTemplates('diseases', 'diseases-management-templates', function() {
                    require(['views/diseasesView'], function(browsePageVw) {
                        var browsePageView = new browsePageVw({
                            "router" : self.router,
                            "parentView" : self,
                            "data" : json.data
                        });
                        self.currentPageTemplate = "diseases-management-templates";
                        self.currentPageView = browsePageView;
                        self.childViews.push(browsePageView);
                        browsePageView.render();
                    });
                });
            },function(){},"POST");
        },
        renderhospitalsDetails : function () {
            var input_json = {
                "role": localStorage.getItem('session_userRole'),
                "username": localStorage.getItem('session_userId'),
            }
            $('#side-menu li.redirectTag').removeClass('active');
            // $('li[datakey=landingDashboard]').addClass('active');
            $(".redirectTag[dataKey='hospitalsDetails']").addClass('active');
            var self = this;
            loadService('hospitalsDataLoad', "" , function(json){
                getTemplates('hospitalsDetails', 'hospitals-details-templates', function() {
                    require(['views/hospitalsDetailsView'], function(browsePageVw) {
                        var browsePageView = new browsePageVw({
                            "router" : self.router,
                            "parentView" : self,
                            "data" : json.data
                        });
                        self.currentPageTemplate = "hospitals-details-templates";
                        self.currentPageView = browsePageView;
                        self.childViews.push(browsePageView);
                        browsePageView.render();
                    });
                });
            },function(){},"POST");
        },
        renderbloodBanks : function () {
            $('#side-menu li.redirectTag').removeClass('active');
            // $('li[datakey=landingDashboard]').addClass('active');
            $(".redirectTag[dataKey='bloodBanks']").addClass('active');
            var self = this;
            loadService('bloodBanksDataLoad', "" , function(json){
                getTemplates('bloodBanks', 'bloodbank_details_templates', function() {
                    require(['views/bloodBanksView'], function(browsePageVw) {
                        var browsePageView = new browsePageVw({
                            "router" : self.router,
                            "parentView" : self,
                            "data" : json.data
                        });
                        self.currentPageTemplate = "bloodbank_details_templates";
                        self.currentPageView = browsePageView;
                        self.childViews.push(browsePageView);
                        browsePageView.render();
                    });
                });
            },function(){},"GET");
        },
        renderlaboratoriesDetails : function () {
            $('#side-menu li.redirectTag').removeClass('active');
            // $('li[datakey=landingDashboard]').addClass('active');
            $(".redirectTag[dataKey='laboratoriesDetails']").addClass('active');
            var self = this;
            // loadService('adminDashboardLoad', "" , function(json){
                getTemplates('laboratoriesDetails', 'laboratories-details-templates', function() {
                    require(['views/laboratoriesDetailsView'], function(browsePageVw) {
                        var browsePageView = new browsePageVw({
                            "router" : self.router,
                            "parentView" : self
                            // "data" : json.data
                        });
                        self.currentPageTemplate = "laboratories-details-templates";
                        self.currentPageView = browsePageView;
                        self.childViews.push(browsePageView);
                        browsePageView.render();
                    });
                });
            // },function(){},"POST");
        },
        renderdoctorsDetails : function () {
            var input_json = {
                "role": localStorage.getItem('session_userRole'),
                "username": localStorage.getItem('session_userId'),
            }
            $('#side-menu li.redirectTag').removeClass('active');
            // $('li[datakey=landingDashboard]').addClass('active');
            $(".redirectTag[dataKey='doctorsDetails']").addClass('active');
            var self = this;
            loadService('doctorDetails', input_json , function(json){
                getTemplates('doctorsDetails', 'doctors-details-templates', function() {
                    require(['views/doctorsDetailsView'], function(browsePageVw) {
                        var browsePageView = new browsePageVw({
                            "router" : self.router,
                            "parentView" : self,
                            "data" : json.data
                        });
                        self.currentPageTemplate = "doctors-details-templates";
                        self.currentPageView = browsePageView;
                        self.childViews.push(browsePageView);
                        browsePageView.render();
                    });
                });
            },function(){},"POST");
        },
        renderpatientsDetails : function () {
            var input_json = {
                "role": localStorage.getItem('session_userRole'),
                "username": localStorage.getItem('session_userId'),
            }
            $('#side-menu li.redirectTag').removeClass('active');
            // $('li[datakey=landingDashboard]').addClass('active');
            $(".redirectTag[dataKey='patientsDetails']").addClass('active');
            var self = this;
            loadService('patientDetails', input_json , function(json){
                getTemplates('patientsDetails', 'patients-details-templates', function() {
                    require(['views/patientsDetailsView'], function(browsePageVw) {
                        var browsePageView = new browsePageVw({
                            "router" : self.router,
                            "parentView" : self,
                            "data" : json.data
                        });
                        self.currentPageTemplate = "patients-details-templates";
                        self.currentPageView = browsePageView;
                        self.childViews.push(browsePageView);
                        browsePageView.render();
                    });
                });
            },function(){},"POST");
        },
        renderprofileDetails : function () {
            var input_json = {
                "role": localStorage.getItem('session_userRole'),
                "username": localStorage.getItem('session_userId'),
            }
            $('#side-menu li.redirectTag').removeClass('active');
            // $('li[datakey=landingDashboard]').addClass('active');
            $(".redirectTag[dataKey='profileDetails']").addClass('active');
            var self = this;
            loadService('profileDetails', input_json , function(json){
                getTemplates('profile', 'profile-details-templates', function() {
                    require(['views/profileView'], function(browsePageVw) {
                        var browsePageView = new browsePageVw({
                            "router" : self.router,
                            "parentView" : self,
                            "data" : json.data
                        });
                        self.currentPageTemplate = "profile-details-templates";
                        self.currentPageView = browsePageView;
                        self.childViews.push(browsePageView);
                        browsePageView.render();
                    });
                });
            },function(){},"POST");
        },
        renderchangePassword : function () {
            $('#side-menu li.redirectTag').removeClass('active');
            // $('li[datakey=landingDashboard]').addClass('active');
            $(".redirectTag[dataKey='changePassword']").addClass('active');
            var changePass = new changePasswordView({
                "parent" : this,
                "route" : this.router
            })
            changePass.render();
        },
        renderFeedBack : function () {
            $('#side-menu li.redirectTag').removeClass('active');
            // $('li[datakey=landingDashboard]').addClass('active');
            $(".redirectTag[dataKey='feedback']").addClass('active');
            var feedBack = new feedbackView({
                "parent" : this,
                "route" : this.router
            })
            feedBack.render();
        },
        renderappointmentDetails : function () {
            var input_json = {
                "role": localStorage.getItem('session_userRole'),
                "username": localStorage.getItem('session_userId'),
            }
            $('#side-menu li.redirectTag').removeClass('active');
            // $('li[datakey=landingDashboard]').addClass('active');
            $(".redirectTag[dataKey='appointments']").addClass('active');
            var self = this;
            loadService('getAppointment', input_json , function(json){
                getTemplates('appointment', 'appointment-details-templates', function() {
                    require(['views/appointmentView'], function(browsePageVw) {
                        var browsePageView = new browsePageVw({
                            "router" : self.router,
                            "parentView" : self,
                            "data" : json.data
                        });
                        self.currentPageTemplate = "appointment-details-templates";
                        self.currentPageView = browsePageView;
                        self.childViews.push(browsePageView);
                        browsePageView.render();
                    });
                });
            },function(){},"POST");
        },
        rendermedicalHistory : function () {
            var input_json = {
                "role": localStorage.getItem('session_userRole'),
                "username": localStorage.getItem('session_userId'),
            }
            $('#side-menu li.redirectTag').removeClass('active');
            // $('li[datakey=landingDashboard]').addClass('active');
            $(".redirectTag[dataKey='medicalHistory']").addClass('active');
            var self = this;
            loadService('medicalHistory', "_session="+btoa(JSON.stringify(input_json)) , function(json){
            getTemplates('medicalHistory', 'medical-history-details-templates', function() {
                require(['views/medicalHistoryView'], function(browsePageVw) {
                    var browsePageView = new browsePageVw({
                        "router" : self.router,
                        "parentView" : self,
                        "data" : json.data
                    });
                    self.currentPageTemplate = "medical-history-details-templates";
                    self.currentPageView = browsePageView;
                    self.childViews.push(browsePageView);
                    browsePageView.render();
                });
            });
            },function(){},"GET");
        },
	});


	var changePasswordView = NeoBackboneView.extend({
        tagName : 'div',
        className : 'content',
        template: this.template = _.template($('#change_password_template').html()),
        initialize: function (obj) {
            this.parent = obj.parent;
            this.router = obj.route;
        },
        events: {
            "click .change-password" : "changePassword"
        },
        render: function () {
            var browseHtml = this.template({});
            this.$el.html(browseHtml);
            $('#page-content').html(this.$el);
        },
        changePassword : function () {
            var self = this;
            var oldpass = $('.old-password').val();
            var pass1 = $('.new-password').val();
            var pass2 = $('.new-password-2').val();
            if (oldpass){
                var input_json = {
                    "role": localStorage.getItem('session_userRole'),
                    "username": localStorage.getItem('session_userId'),
                    "password": btoa(oldpass)
                }
                loadService('userLoginCheck', input_json , function(json){
                    if (json.data.username){
                        if(pass2 && pass1){
                            input_json['newPass'] = pass1
                            loadService("userChangePassword",input_json,function (json) {
                                if(json.status == 'success'){
                                    $.notify('Password changed Successfully','success')
                                }else {
                                    $.notify('Error while changing password','error')
                                }
                            },function(){},"POST");
                        }else{
                            $.notify('New password does not matching','error')
                        }
                    }else{
                        $.notify('Old password does not matching','error')
                    }
                },function(){},"POST");
            }
            
        }
    });

    var feedbackView = NeoBackboneView.extend({
        tagName : 'div',
        className : 'content',
        template: this.template = _.template($('#feedback_templates').html()),
        initialize: function (obj) {
            this.parent = obj.parent;
            this.router = obj.route;
        },
        events: {
            "click .submit-feedback": "feedBack"
        },
        render: function () {
            var browseHtml = this.template({});
            this.$el.html(browseHtml);
            $('#page-content').html(this.$el);
        },
        feedBack: function () {
            var feedback = $('.feedback-da').val();
            var input_json = {
                "role": localStorage.getItem('session_userRole'),
                "username": localStorage.getItem('session_userId'),
                "feedback": feedback
            }
            if (feedback){
                loadService('submitFeedback', input_json , function(json){
                    if (json.data.success){
                        $.notify('Submitted Feedback','success')
                    }else{
                        $.notify('Error While Submitting Feedback','error')
                    }
                },function(){},"POST");
            }
        }
    });
	
	return redirectView;
});
