define(['datatables'], function() {
    var DashboardViewAdmin = NeoBackboneView.extend({
        tagName: 'div',
        className: 'content',
        template : this.template = _.template($('#admin_dashboard_template').html()),
        initialize: function (obj) {
            this.router = obj.router;
            this.parentView = obj.parentView;
            this.model = obj.data;
        },
        events: {

        },
        render: function () {
            var browseHtml = this.template({"data": this.model});
            this.$el.html(browseHtml);
            $('#page-content').html(this.$el);
            this.defaultScript();
            var barChartData = this.model.bar_chart_data;
        
            var ctx = $('#bargraph');
            new Chart(ctx, {
                type: 'bar',
                data: barChartData,
                options: {
                    responsive: true,
                    legend: {
                        display: false,
                    }
                }
            });

            var lineChartData = this.model.line_chart_data;
            
            var linectx = $('#linegraph');
            new Chart(linectx, {
                type: 'line',
                data: lineChartData,
                options: {
                    responsive: true,
                    legend: {
                        display: false,
                    },
                    tooltips: {
                        mode: 'index',
                        intersect: false,
                    }
                },
            });
            $('.bar-chart').find('.item-progress').each(function(){
                var itemProgress = $(this),
                itemProgressWidth = $(this).parent().width() * ($(this).data('percent') / 100);
                itemProgress.css('width', itemProgressWidth);
            });
        },
        defaultScript : function () {
            $('.dataTables-example').DataTable({
                dom: '<"html5buttons"B>lTfgitp',
                buttons: [
                    { extend: 'copy'},
                    {extend: 'csv'},
                    {extend: 'excel', title: 'ExampleFile'},
                    {extend: 'pdf', title: 'ExampleFile'},

                    {extend: 'print',
                        customize: function (win){
                            $(win.document.body).addClass('white-bg');
                            $(win.document.body).css('font-size', '10px');

                            $(win.document.body).find('table')
                                .addClass('compact')
                                .css('font-size', 'inherit');
                        }
                    }
                ]

            });
        },
    });
    return DashboardViewAdmin;
});