/**
 * Created by getit on 19-04-2017.
 */
define(['datatables'], function() {
    var diseasesView = NeoBackboneView.extend({
        tagName: 'div',
        className: 'content',
        template : this.template = _.template($('#diseases_management_template').html()),
        initialize: function (obj) {
            this.router = obj.router;
            this.parentView = obj.parentView;
            this.model = obj.data;
        },
        events: {
            "change .project-id" : "changeModule"
        },
        render: function () {
            var role = localStorage.getItem('session_userRole')
            var browseHtml = this.template({'data' : this.model, 'role': role});
            this.$el.html(browseHtml);
            $('#page-content').html(this.$el);
            this.defaultScript();
            $('.datatable').DataTable({
                "bFilter": true,
            });
        },
        defaultScript : function () {

        },
        changeModule : function (e) {
            var module = $('option:selected', e.currentTarget).data('value');
            var htm;
            var i;
            for(i=1; i<=module;i++){
                htm += '<option value="'+i+'">Module '+i+'</option>'
            }
            $('.project-module').html(htm);
        }
    });
    return diseasesView;
});