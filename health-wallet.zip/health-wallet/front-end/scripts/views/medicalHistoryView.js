/**
 * Created by getit on 19-04-2017.
 */
 define(['datatables', 'select2', 'datetimepicker', 'editable', 'bootBox'], function() {
    var appointmentView = NeoBackboneView.extend({
        tagName: 'div',
        className: 'content',
        template : this.template = _.template($('#medical_history_details_templates').html()),
        initialize: function (obj) {
            this.router = obj.router;
            this.parentView = obj.parentView;
            this.model = obj.data;
        },
        events: {
            "click .btn-add" : "addHistory",
            "click .patien-history": "getPatientHistory",
        },
        render: function () {
            var role = localStorage.getItem('session_userRole')
            var browseHtml = this.template({'role': role, data: this.model});
            this.$el.html(browseHtml);
            $('#page-content').html(this.$el);
            this.defaultScript();
            $('.datatable').DataTable({
                "bFilter": false,
            });
        },
        defaultScript : function () {

        },
        addHistory : function (e) {
            var input_json = {
                "role": localStorage.getItem('session_userRole'),
                "username": localStorage.getItem('session_userId'),
                "action": "add"
            }
            loadService('medicalHistory', "_session="+btoa(JSON.stringify(input_json)) , function(json){
                var medicalHistoryPopup = new addMedHistory({
                    "parent" : this,
                    "route" : this.router,
                    "data": json.data
                })
                medicalHistoryPopup.render();
            },function(){},"GET");
        },
        getPatientHistory: function (e) {
            const cv = this
            var id = $(e.currentTarget).data('id')
            $.each(cv.model.result, function(index, value){
                if (value.id === id.trim()){
                    var historyPopup = new patientMedicalHistory({
                        "parent" : cv,
                        "route" : cv.router,
                        "data": value
                    })
                    historyPopup.render();
                }
            })
        }
    });

    var addMedHistory = NeoBackboneView.extend({
        tagName: 'div',
        className: 'content',
        template: this.template = _.template($('#medical_history_add_templates').html()),
        initialize: function (obj) {
            this.router = obj.router;
            this.parentView = obj.parentView;
            this.model = obj.data;
            this.hospital_info = {}
            this.hs_email = null
            this.medicines = []
            this.lab_tests = []
            this.tags = []
        },
        events: {
            "change .apnmt-hspt-name": "loadDepartment",
            "change #department_select": "loadDoctors",

            "keyup .medicine-search": "searchMedicine",
            "click span.medicine-search": "searchMedicine",
            "click .select-medicine": "selectMedicine",
            "change .test-spcecimen": "changeLabTest",
            "change .test-select": "selectLabTest",
            "change .select-symptom": "selectSymptom",
            "click .close-tag": "closeTag",
            "click .editable-text": "calculateBmi",
            "click .save-details": "saveDetails",
            "keyup [data-key]": "removeValidation",
            "change [data-key]": "removeValidation",
        },
        render: function () {
            var browseHtml = this.template({"data" : this.model});
            this.$el.html(browseHtml);
            $('#page-content').html(this.$el);
            $('.apnmt-hspt-name').select2({
                width: '100%',
                placeholder: "Please select a Hospital"
            });
            $('#department_select').select2({
                width: '100%',
                placeholder: "Please select a Department"
            });
            $('.doctor-select').select2({
                width: '100%',
                placeholder: "Please select a Doctor"
            });
            $('#datetimepicker3').datetimepicker({
                format: 'LT'

            });
            $('.datetimepicker').datetimepicker({
                format: 'DD/MM/YYYY'
            });
            cv = this
            $.each(this.model.result.hospitals, function(ind,val){
                cv.hospital_info[val.id] = val
            });

            $('.test-select').select2({
                width: '100%',
                placeholder: "Please select a Lab Specimen",
            });

            $('.test-spcecimen').select2({
                width: '100%',
                placeholder: "Please select a Lab Test",
            });
            $('.disease-name').select2({
                width: '100%',
                tags: true
            });
            $('.editable-text').editable({
                mode: 'inline',
            });
            
            $('.select-symptom').select2({
                width: '100%',
                tags: true
            });
        },
        loadDepartment: function(e) {
            var cv = this
            var hs_id = $(e.currentTarget).val()
            if (hs_id != null){
                $('.hs-location').val(this.hospital_info[hs_id]['location'])
                $('.hs-phone').val(this.hospital_info[hs_id]['phone'])
                cv.hs_id = hs_id
                var opts = [{
                    id: "-1",
                    text: '--- Please select a Department ---',
                    selected:'selected'
                  }]
                $("#department_select"). empty();
                $('#department_select').select2({
                    width: '100%',
                    placeholder: "Please select a Department",
                });
                $(".doctor-select"). empty();
                $('.doctor-select').select2({
                    width: '100%',
                    placeholder: "Please select a Doctor",
                });
                var a = false
                $.each(this.hospital_info[hs_id]['departments'], function(ind, val){
                    opts.push({id: ind, text: ind})
                })
                $('#department_select').select2({
                    width: '100%',
                    data: opts,
                    placeholder: "Please select a Department",
                });
            }
            
        },
        loadDoctors: function (e) {
            var cv = this
            var dep = $(e.currentTarget).val()
            if (dep != null && cv.hs_id != null && dep != -1){
                var opts = []
                $(".doctor-select"). empty();
                $('.doctor-select').select2({
                    width: '100%',
                    placeholder: "Please select a Doctor",
                });
                $.each(this.hospital_info[cv.hs_id]['departments'][dep]['doctors'], function(ind, val){
                    opts.push({id: val.id+"_"+val.name, text: val.name})
                })
                $('.doctor-select').select2({
                    width: '100%',
                    data: opts,
                    placeholder: "Please select a Doctor",
                });
            }else if ( dep == -1){
                $(".doctor-select"). empty();
                $('.doctor-select').select2({
                    width: '100%',
                    placeholder: "Please select a Doctor",
                });
            }
        },
        searchMedicine: function(e) {
            var val = $('input.medicine-search').val()
            if (val.length > 2){
                $('#search_suggestion').css('display', 'block')
                var html=""
                loadService('searchMedicine', {"text": val} , function(json){
                    if(json.data.result){
                        $.each(json.data.result, function(ind, val){
                            html+= '<div class="col-md-12 select-medicine" data-id="'+val.id+'">'+val.name+'</div>'
                        })
                        $('#search_suggestion').html(html)
                    }
                },function(){},"POST");
            }else if(val.length ==0){
                $('#search_suggestion').css('display', 'none')
            }
        },
        selectMedicine: function(e) {
            var name = $(e.currentTarget).html()
            var cv = this
            if (name && cv.medicines.indexOf(name) == -1){
                if ($('.temp-medicine').length == 1){
                    $('#medicine-prescribed').html("")
                }
                cv.medicines.push(name)
                $('#search_suggestion').css('display', 'none')
                var temp = _.template($('#prescribe_medicine_templates').html())({name: name})
                $('#medicine-prescribed').append(temp)
                $('#medicine-prescribed').next("span.validation").remove();
            }  
        },
        changeLabTest: function(e) {
            var specimen = $('.test-spcecimen  option:selected').text().trim()
            var value = $(e.currentTarget).val()
            if (value !== '0'){
                $('.test-select').prop("disabled", false);
                $(".test-select"). empty();
                $('.test-select').select2({
                    width: '100%',
                    placeholder: "Please select a Lab Test Name",
                });
                loadService('getSpecimen', "specimen="+specimen , function(json){
                    if(json.data.result){
                        var opts = [{id:0, text: "select an option"}]
                        $.each(json.data.result, function(ind, val){
                            opts.push({id: val.id, text: val.test})
                        })
                        $('.test-select').select2({
                            width: '100%',
                            data: opts,
                            placeholder: "Please select a Lab Test Name",
                        });
                    }
                },function(){},"GET");
            }else{
                $(".test-select"). empty();
                $('.test-select').select2({
                    width: '100%',
                    placeholder: "Please select a Lab Test Name",
                });
                $('.test-select').prop("disabled", true);
            }
        },
        selectLabTest: function(e){
            var test_id = $(e.currentTarget).val()
            let cv = this
            if (test_id !== undefined && test_id !== '0'){
                if (test_id && cv.lab_tests.indexOf(test_id) == -1){
                    $.each(cv.model.result.lab_details, function(index, value){
                        if (value.id === test_id){
                            console.log(value)
                            bootbox.prompt({
                                title: 'Observed Value for the '+ value.specimen +' Test',
                                message: '<p>Normal Readings <span style="color: green;">'+ value.conventional_units +'</span></p><label>Enter Value</label>',
                                inputType: 'text',
                                onEscape: false,
                                closeButton: false,
                                buttons: {
                                    confirm: {
                                        label: 'Yes',
                                        className: 'btn-success'
                                    },
                                    cancel: {
                                        label: 'No',
                                        className: 'btn-danger'
                                    }
                                },
                                callback: function (result) {
                                    if (result){
                                            value.result = result
                                            if ($('.temp-tests').length == 1){
                                                $('#labtests-prescribed').html("")
                                            }
                                            cv.lab_tests.push(test_id)
                                            $('#search_suggestion').css('display', 'none')
                                            var temp = _.template($('#prescribe_labtest_templates').html())({data: value})
                                            $('#labtests-prescribed').append(temp)
                                            
                                            
                                    }else {
                                        $('.test-select').val('0'); 
                                        $('.test-select').trigger('change');
                                    }
                                }
                            });
                        } 
                    });
                }
            }
        },
        selectSymptom: function(e){
            var cv = this
            var symptom= $(e.currentTarget).val()
            if (symptom && symptom !== "0" && cv.tags.indexOf(symptom) == -1){
                cv.tags.push(symptom.trim())
                $(e.currentTarget).val("")
                cv.updateTags()
            }
        },
        updateTags: function(){
            $('.tags-container').html('')
            $.each(this.tags, function(index, value){
                $('.select-symptom').val('0'); // Select the option with a value of 'US'
                $('.select-symptom').trigger('change');
                html = '<div class="tags">'+value+'<i class="fa fa-close close-tag" data-value="'+value+'"></i></div>'
                $('.tags-container').append(html)
            })
        },
        closeTag: function(e){
            const cv = this
            let value = $(e.currentTarget).data('value');
            if (value){
                const index = cv.tags.indexOf(value);
                if (index > -1) {
                    cv.tags.splice(index, 1);
                }
                cv.updateTags()
            }
        },
        calculateBmi: function(e){
            $(e.currentTarget).css('color', '#0088cc')
            let height = $('a[data-key="height"]').text()
            let weight = $('a[data-key="weight"]').text()
            if (height && weight){
                console.log("reached")
                var bmi = Math.round([Number(weight)/Number(height)/Number(height)] * 10000) 
                $('a[data-key="bmi"]').html(bmi)
                $('a[data-key="bmi"]').css('color', '#0088cc')
                console.log(bmi)
            }
        },
        saveDetails: function(){
            const cv = this;
            let required = {}
            let valid = true
            var data = {}
            data['hospital_id'] = $('.apnmt-hspt-name').val();
            data['department'] = $('#department_select').val();
            data['date'] = $('#from-date').val();
            data['time'] = '10:00 AM';
            data['active'] = false;
            data['role'] = 'patient';
            data['patient_name'] = cv.model.result.patient_details.name;
            data['patient_email'] = cv.model.result.patient_details.email;
            data['message'] = $('.appointment-msg').val();
            let doctor_data = $(".doctor-select"). val();
            let doctor_name, doctor_id = ""
            if (doctor_data){
                doctor_id = doctor_data.split("_")[0]
                doctor_name = doctor_data.split("_")[1]
            }
            data['doctor_id'] = doctor_id
            data['doctor_name'] = doctor_name
            var input_data = {}
            let req_list = ['symptoms', 'comments', 'condition', 'medicines', 'lab_test']
            let error_template = '<span class="validation" style="color: red">This Field is required</span>'
            if (!data['doctor_id']){
                $(".doctor-select").append(error_template)
            }
            if (!data['date']){
                $("#from-date").append(error_template)
            }
            $.each($('[data-key]'), function(ind,attribute){
                let key = $(attribute).data('key')
                let value = $(attribute).text().trim()
                if (value === "" || key === "condition"){
                    value = $(attribute).val()
                }
                if (key === "symptoms"){
                    value = []
                    $.each($(attribute).find('.tags'), function(tagIndex, tagValue){
                        value.push($(tagValue).text().trim())
                    })
                }
                $.each(["Add Test here", "Add Medicines here", "Select/Add Disease Name"], function(index, item){
                    if (value.indexOf(item) !== -1){
                        value = ""
                    }
                })
                let required = $(attribute).data('required')
                console.log(required)
               
                if (required && (value === "" || value === "0" | value === [])){
                    if (req_list.indexOf(key) !== -1){
                        $(attribute).next("span.validation").remove();
                        if (key === "symptoms"){
                            $(attribute).append(error_template)
                        }else{
                            $(attribute).after(error_template)
                        }
                        valid = false
                    }else{
                        $(attribute).css('color', 'red')
                        valid = false
                    }
                }else {
                    if (key === "medicines"){
                        let medicines = []
                        $.each($('.medicine-row'), function(index, item){
                            let medicine_item = {}
                            $.each($(item).find('[data-attr]'), function(tdIndex, tdValue){
                                let schedule = {}
                                let attr_key = $(tdValue).data('attr')
                                let attr_value = $(tdValue).text().trim()
                                if (attr_value === ""){
                                    attr_value = $(tdValue).val().trim()
                                }
                                if (attr_key === "schedule"){
                                    let count = 0
                                    $.each($(tdValue).find('[data-item]'), function(i, val){
                                        let sch_key = $(val).data('item')
                                        let sch_val = $(val)[0].checked
                                        if (sch_val){
                                            count = count + 1
                                            console.log(sch_val)
                                        }
                                        schedule[sch_key] = sch_val
                                        attr_value = schedule
                                    })
                                    if (count === 0){
                                        $(attribute).next("span.validation").remove();
                                        $(attribute).after(error_template)
                                        valid = false
                                    }
                                }else if (attr_value === 0 || attr_value === ""){
                                    $(attribute).next("span.validation").remove();
                                    $(attribute).after(error_template)
                                    valid = false
                                }
                                medicine_item[attr_key] = attr_value
                            })
                            if (valid){
                                medicines.push(medicine_item)
                            }
                        })
                        value = medicines
                    }else if (key === "lab_test" && value !== ""){
                        let lab_test = []
                        $.each($('.lab-test-row'), function(index, item){
                            let test_item = {}
                            $.each($(item).find('[data-attr]'), function(tdIndex, tdValue){
                                let attr_key = $(tdValue).data('attr')
                                let attr_value = $(tdValue).text().trim()
                                if (attr_value === 0 || attr_value === ""){
                                    $(attribute).next("span.validation").remove();
                                    $(attribute).after(error_template)
                                    valid = false
                                }
                                test_item[attr_key] = attr_value
                            })
                            if (valid){
                                lab_test.push(test_item)
                            }
                        })
                        value = lab_test
                    }
                    input_data[key] = value
                }

            })
            
            if(valid && data['hospital_id'] && data['department'] && data['doctor_id']){
                data['prescription'] = input_data
                data['condition'] = input_data.condition
                
                console.log(data)
                loadService("addPrescription",data,function (json) {
                    if (json.status){
                        $.notify('Appointment successfully Updated', 'success');
                        cv.rendermedicalHistory()
                    }else{
                        $.notify(json.message, 'error');
                    }
                },function(){},"POST");
            }else{
                $.notify('The fields Marked in red color are required', 'error');
            }

        },
        removeValidation: function(e){
            $(e.currentTarget).css('color', 'black')
            $(e.currentTarget).next("span.validation").remove();
        },
        rendermedicalHistory : function () {
            var input_json = {
                "role": localStorage.getItem('session_userRole'),
                "username": localStorage.getItem('session_userId'),
            }
            $('#side-menu li.redirectTag').removeClass('active');
            // $('li[datakey=landingDashboard]').addClass('active');
            $(".redirectTag[dataKey='medicalHistory']").addClass('active');
            var self = this;
            loadService('medicalHistory', "_session="+btoa(JSON.stringify(input_json)) , function(json){
            getTemplates('medicalHistory', 'medical-history-details-templates', function() {
                require(['views/medicalHistoryView'], function(browsePageVw) {
                    var browsePageView = new browsePageVw({
                        "router" : self.router,
                        "parentView" : self,
                        "data" : json.data
                    });
                    self.currentPageTemplate = "medical-history-details-templates";
                    self.currentPageView = browsePageView;
                    self.childViews.push(browsePageView);
                    browsePageView.render();
                });
            });
            },function(){},"GET");
        },
        
    });

    var patientMedicalHistory = NeoBackboneView.extend({
        tagName: 'div',
        className: 'content',
        template: this.template = _.template($('#patient_medical_history_templates').html()),
        initialize: function (obj) {
            this.router = obj.router;
            this.parentView = obj.parentView;
            this.model = obj.data;
            this.hospital_info = {}
            this.hs_email = null
            this.medicines = []
            this.lab_tests = []
            this.tags = []
        },
        events: {
            // "click div": "hideSearch",
            "click .close-details": "rendermedicalHistory"
        },
        render: function () {
            var cv = this
            var browseHtml = this.template({"data" : this.model});
            this.$el.html(browseHtml);
            $('#page-content').html(this.$el);
        },
       
        selectSymptom: function(e){
            var cv = this
            var symptom= $(e.currentTarget).val()
            if (symptom && symptom !== "0" && cv.tags.indexOf(symptom) == -1){
                cv.tags.push(symptom.trim())
                $(e.currentTarget).val("")
                cv.updateTags()
            }
        },
        rendermedicalHistory : function () {
            var input_json = {
                "role": localStorage.getItem('session_userRole'),
                "username": localStorage.getItem('session_userId'),
            }
            $('#side-menu li.redirectTag').removeClass('active');
            // $('li[datakey=landingDashboard]').addClass('active');
            $(".redirectTag[dataKey='medicalHistory']").addClass('active');
            var self = this;
            loadService('medicalHistory', "_session="+btoa(JSON.stringify(input_json)) , function(json){
            getTemplates('medicalHistory', 'medical-history-details-templates', function() {
                require(['views/medicalHistoryView'], function(browsePageVw) {
                    var browsePageView = new browsePageVw({
                        "router" : self.router,
                        "parentView" : self,
                        "data" : json.data
                    });
                    self.currentPageTemplate = "medical-history-details-templates";
                    self.currentPageView = browsePageView;
                    self.childViews.push(browsePageView);
                    browsePageView.render();
                });
            });
            },function(){},"GET");
        },
        // hideSearch: function(e) {
        //     var classname = $(e.currentTarget).attr('class')
        //     if (classname !== "col-md-12 select-medicine"){
        //         if ($('#search_suggestion').attr('style').includes('block')){
        //         }
        //     }
        // }
        
    });
    return appointmentView;
});