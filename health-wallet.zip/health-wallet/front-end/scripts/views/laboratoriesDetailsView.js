/**
 * Created by getit on 19-04-2017.
 */
 define(['datatables'], function() {
    var hospitalsDetailsView = NeoBackboneView.extend({
        tagName: 'div',
        className: 'content',
        template : this.template = _.template($('#laboratories_details_templates').html()),
        initialize: function (obj) {
            this.router = obj.router;
            this.parentView = obj.parentView;
            this.model = obj.data;
        },
        events: {
            "click .btn-register-complaint" : "registerComplaint",
            "change .project-id" : "changeModule"
        },
        render: function () {
            var browseHtml = this.template({'data' : this.model});
            this.$el.html(browseHtml);
            $('#page-content').html(this.$el);
            this.defaultScript();
            $('.datatable').DataTable({
                "bFilter": false,
            });
        },
        defaultScript : function () {

        },
        registerComplaint : function () {
            var complaint = $('.complaint').val();
            var input = {
                'feedback': complaint,
                'customerId': session_userId
            }
            if(complaint){
                loadService('addFeedback',input,function (json) {
                    if(json.status == 'success' ){
                        $.notify('Added successfully', 'success');
                        $('.form-control').val('');
                    } else {
                        $.notify('Error While adding', 'error');
                    }
                })
            }
        },
        changeModule : function (e) {
            var module = $('option:selected', e.currentTarget).data('value');
            var htm;
            var i;
            for(i=1; i<=module;i++){
                htm += '<option value="'+i+'">Module '+i+'</option>'
            }
            $('.project-module').html(htm);
        }
    });
    return hospitalsDetailsView;
});