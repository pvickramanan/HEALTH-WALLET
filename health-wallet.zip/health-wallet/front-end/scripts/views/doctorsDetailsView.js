/**
 * Created by getit on 19-04-2017.
 */
 define(['datatables','select2'], function() {
    var hospitalsDetailsView = NeoBackboneView.extend({
        tagName: 'div',
        className: 'content',
        template : this.template = _.template($('#doctors_details_templates').html()),
        initialize: function (obj) {
            this.router = obj.router;
            this.parentView = obj.parentView;
            this.model = obj.data;
        },
        events: {
            "change .project-id" : "changeModule",
            "click .btn-add-doctor" : "addDoctor"
        },
        render: function () {
            var role = localStorage.getItem('session_userRole');
            var browseHtml = this.template({'data' : this.model, 'getAge': this.getAge, 'role': role});
            this.$el.html(browseHtml);
            $('#page-content').html(this.$el);
            this.defaultScript();
            $('.datatable').DataTable({
                "bFilter": true,
                "columnDefs": [
                    { "targets": [2,3,4,5], "searchable": false }
                ]
            });
        },
        defaultScript : function () {

        },
        changeModule : function (e) {
            var module = $('option:selected', e.currentTarget).data('value');
            var htm;
            var i;
            for(i=1; i<=module;i++){
                htm += '<option value="'+i+'">Module '+i+'</option>'
            }
            $('.project-module').html(htm);
        },
        getAge : function (date_str) {
            var birthday = new Date(date_str)
            var ageDifMs = Date.now() - birthday.getTime();
            var ageDate = new Date(ageDifMs); // miliseconds from epoch
            return Math.abs(ageDate.getUTCFullYear() - 1970);
        },
        addDoctor : function() {
            var addDoctorDetailsPopup = new addDoctorDetails({
                    "parent" : this,
                    "route" : this.router,
//                    "data": json.data,

                })
                addDoctorDetailsPopup.render();
        }
    });
        var addDoctorDetails = NeoBackboneView.extend({
        tagName: 'div',
        className: 'content',
        template: this.template = _.template($('#add_doctor_templates').html()),
        initialize: function (obj) {
            this.router = obj.router;
            this.parentView = obj.parentView;
//            this.model = obj.data;

        },
        events: {
//        "change .apnmt-hspt-name": "loadDepartment"

        },
        render: function () {
            var browseHtml = this.template({"data" : this.model, "edit_data": this.edit_data, "operation": this.operation});
            this.$el.html(browseHtml);
            $('#page-content').html(this.$el);
            $('#department_select').select2({
                width: '100%',
                data: [{"id": 1, "text": "general"}, {"id": 2, "text": "ENT"}],
                placeholder: "Please select a Department"
            });



        }

    });
    return hospitalsDetailsView;
});