/**
 * Created by getit on 19-04-2017.
 */
 define(['datatables'], function() {
    var patientsDetailsView = NeoBackboneView.extend({
        tagName: 'div',
        className: 'content',
        template : this.template = _.template($('#patients_details_templates').html()),
        initialize: function (obj) {
            this.router = obj.router;
            this.parentView = obj.parentView;
            this.model = obj.data;
            this.role = localStorage.getItem('session_userRole')
        },
        events: {
            "change .project-id" : "changeModule",
            'keyup input[aria-controls="DataTables_Table_1"]': 'searchPatient'
        },
        render: function () {
            var role = localStorage.getItem('session_userRole')
            var browseHtml = this.template({'role': role, 'data' : this.model});
            this.$el.html(browseHtml);
            $('#page-content').html(this.$el);
            this.defaultScript();
            if (role === "admin"){
                this.dataTable = $('.datatable').DataTable({
                    "bFilter": false,
                    // "columnDefs": [
                    //     { "targets": [2,3,4,5], "searchable": false }
                    // ]
                });
            }else{
                this.dataTable = $('.datatable').DataTable({
                    "bFilter": true,
                    "columnDefs": [
                        { "targets": [2,3,4,5], "searchable": false }
                    ]
                });
            }
        },
        defaultScript : function () {

        },
        changeModule : function (e) {
            var module = $('option:selected', e.currentTarget).data('value');
            var htm;
            var i;
            for(i=1; i<=module;i++){
                htm += '<option value="'+i+'">Module '+i+'</option>'
            }
            $('.project-module').html(htm);
        },
        searchPatient: function(e) {
            let input = $(e.currentTarget).val();
            if (input.length >= 3 || input.length === 0){
                var input_json = {
                    "role": localStorage.getItem('session_userRole'),
                    "username": localStorage.getItem('session_userId'),
                    "input": input
                }
                var cv = this;
                loadService('patientDetails', input_json , function(json){
                    cv.dataTable.destroy();
                    var temp = _.template($('#patients_result_templates').html())({'data': json.data, 'role': cv.role})
                    $('.patient-body').html(temp)
                    cv.dataTable = $('.datatable').DataTable({
                        "bFilter": true,
                        "columnDefs": [
                            { "targets": [2,3,4,5], "searchable": false }
                        ]
                    });
                },function(){},"POST");
            }
        }
    });
    return patientsDetailsView;
});