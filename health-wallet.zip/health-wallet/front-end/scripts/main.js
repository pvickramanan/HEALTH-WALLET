require(['jquery', 'underscore', 'backbone', "jquery-ui", "bootstrap", "app", 'datetimepicker'], function ($, _, backbone) {
    NeoBackboneView = NeoBackBonePrototype($, _, backbone);
    require(['views/redirectView'], function (redirectView) {
        var intermediateView;
        var currentPageView;
        var intervalHandle = undefined;

        var Router = Backbone.Router.extend({
            routes: {
                "": "login",
                "login": "login",
                "register": "register",
                "logout": "logout",
                "Dashboard": "Dashboard",
                "bloodBanks": "bloodBanks",
                "diseaseMangement": "diseaseMangement",
                "hospitalsDetails": "hospitalsDetails",
                "laboratoriesDetails": "laboratoriesDetails",
                "doctorsDetails": "doctorsDetails",
                "patientsDetails": "patientsDetails",
                "profileDetails": "profileDetails",
                "changePassword": "changePassword",
                "appointmentDetails": "appointmentDetails",
                "medicalHistory": "medicalHistory",
                "feedback": "feedback"
            },
            login: function () {
                var loginTemplate = _.template($('#login_template').html());
                $('#wrapper').html(loginTemplate({}));
                $('.login-pass').keydown(function (e) {
                    if (e.which === 13) {
                        loginCallback(e)
                    }
                });
                $('.btn-login-check').click(function (e) {
                    loginCallback(e)
                });
            },
            register: function () {
                var loginTemplate = _.template($('#register_template').html());
                $('#wrapper').html(loginTemplate({}));
                $('.btn-email-check').click(function (e) {
                    signUpCallback(e)
                })
            },
            logout: function (){
                localStorage.removeItem("session_userId");
                localStorage.removeItem('session_userName');
                localStorage.removeItem('session_userRole');
                window.location.href = "";
            },
            Dashboard: function () {
                initializeIntermediateView(function () {
                    loadService(localStorage.getItem('landingScreenOptions'), '', function (json) {
                        intermediateView = new redirectView({
                            "router": router,
                            "data": json.data
                        });
                        intermediateView.render();
                        intermediateView.renderDashboard();
                    })
                });
            },
            diseaseMangement : function () {
                initializeIntermediateView(function () {
                    loadService(localStorage.getItem('landingScreenOptions'), '', function (json) {
                        intermediateView = new redirectView({
                            "router": router,
                            "data": json.data
                        });
                        intermediateView.render();
                        intermediateView.renderdiseaseMangement();
                    })
                });
            },
            hospitalsDetails: function () {
                initializeIntermediateView(function () {
                    loadService(localStorage.getItem('landingScreenOptions'), '', function (json) {
                        intermediateView = new redirectView({
                            "router": router,
                            "data": json.data
                        });
                        intermediateView.render();
                        intermediateView.renderhospitalsDetails();
                    })
                });
            },
            bloodBanks :function () {
                initializeIntermediateView(function () {
                    loadService(localStorage.getItem('landingScreenOptions'), '', function (json) {
                        intermediateView = new redirectView({
                            "router": router,
                            "data": json.data
                        });
                        intermediateView.render();
                        intermediateView.renderbloodBanks();
                    })
                });
            },
            laboratoriesDetails: function () {
                initializeIntermediateView(function () {
                    loadService(localStorage.getItem('landingScreenOptions'), '', function (json) {
                        intermediateView = new redirectView({
                            "router": router,
                            "data": json.data
                        });
                        intermediateView.render();
                        intermediateView.renderlaboratoriesDetails();
                    })
                });
            },
            doctorsDetails: function () {
                initializeIntermediateView(function () {
                    loadService(localStorage.getItem('landingScreenOptions'), '', function (json) {
                        intermediateView = new redirectView({
                            "router": router,
                            "data": json.data
                        });
                        intermediateView.render();
                        intermediateView.renderdoctorsDetails();
                    })
                });
            },
            patientsDetails: function () {
                initializeIntermediateView(function () {
                    loadService(localStorage.getItem('landingScreenOptions'), '', function (json) {
                        intermediateView = new redirectView({
                            "router": router,
                            "data": json.data
                        });
                        intermediateView.render();
                        intermediateView.renderpatientsDetails();
                    })
                });
            },
            profileDetails: function () {
                initializeIntermediateView(function () {
                    loadService(localStorage.getItem('landingScreenOptions'), '', function (json) {
                        intermediateView = new redirectView({
                            "router": router,
                            "data": json.data
                        });
                        intermediateView.render();
                        intermediateView.renderprofileDetails();
                    })
                });
            },
            changePassword: function () {
                initializeIntermediateView(function () {
                    loadService(localStorage.getItem('landingScreenOptions'), '', function (json) {
                        intermediateView = new redirectView({
                            "router": router,
                            "data": json.data
                        });
                        intermediateView.render();
                        intermediateView.renderchangePassword();
                    })
                });
            },
            feedback: function () {
                initializeIntermediateView(function () {
                    loadService(localStorage.getItem('landingScreenOptions'), '', function (json) {
                        intermediateView = new redirectView({
                            "router": router,
                            "data": json.data
                        });
                        intermediateView.render();
                        intermediateView.renderFeedBack();
                    })
                });
            },
            appointmentDetails: function () {
                initializeIntermediateView(function () {
                    loadService(localStorage.getItem('landingScreenOptions'), '', function (json) {
                        intermediateView = new redirectView({
                            "router": router,
                            "data": json.data
                        });
                        intermediateView.render();
                        intermediateView.renderappointmentDetails();
                    })
                });
            },
            medicalHistory: function(){
                initializeIntermediateView(function () {
                    loadService(localStorage.getItem('landingScreenOptions'), '', function (json) {
                        intermediateView = new redirectView({
                            "router": router,
                            "data": json.data
                        });
                        intermediateView.render();
                        intermediateView.rendermedicalHistory();
                    })
                });
            }
        });

        var router = new Router();
        Backbone.history.start();

        function initializeIntermediateView(successFn) {
            if (currentPageView != undefined) {
                currentPageView.removeView();
                destroyView(currentPageView);
            }
            session_userType = localStorage.getItem('session_userType');
            session_userId = localStorage.getItem('session_userId');
            session_userName = localStorage.getItem('session_userName');
            if(session_userType == 'developer'){
                serviceName = 'landingScreenDeveloper';
            }else if(session_userType == 'customer'){
                serviceName = 'landingScreenCustomer';
            }
            if (session_userId == undefined || session_userId == "") {
                localStorage.setItem('--url', window.location.href)
                window.location.href = "";
                return false;
            }
            successFn();
        }

    });

    function detectBrowser() {
        var browserName = '';
        if ($.browser.msie) {
            browserName = 'IE';
            //IE - Internet Explorer
            browserName = browserName + jQuery.browser.version;
            browserName = browserName.substring(0, browserName.indexOf('.'));
        } else if ($.browser.mozilla) {
            browserName = 'MOZ';
            //MOZ- Mozilla Firefox
        } else if ($.browser.webkit) {
            browserName = 'WK';
            //WK- WebKit
        } else if ($.browser.opera) {
            browserName = 'OP';
            //OP - Opera
        }
        return browserName;
    }

    //g_browserType = detectBrowser();
    function loadCss(url) {
        var link = document.createElement("link");
        link.type = "text/css";
        link.rel = "stylesheet";
        link.href = url;
        document.getElementsByTagName("head")[0].appendChild(link);
    }

});

/*
 * GLOBAL VARIABLES
 */
var serviceName
var session_userId = "";
var session_userName = "";
var session_userType = "";
// var session_userRole = "";
/*
 * GLOBAL Methods
 */

$(window).bind("resize", function () {
    if ($(this).width() < 769) {
        $('body').addClass('body-small')
    } else {
        $('body').removeClass('body-small')
    }
});

function SmoothlyMenu() {
    if (!$('body').hasClass('mini-navbar') || $('body').hasClass('body-small')) {
        // Hide menu in order to smoothly turn on when maximize menu
        $('#side-menu').hide();
        // For smoothly turn on menu
        setTimeout(
            function () {
                $('#side-menu').fadeIn(900);
            }, 200);
    } else if ($('body').hasClass('fixed-sidebar')) {
        $('#side-menu').hide();
        setTimeout(
            function () {
                $('#side-menu').fadeIn(900);
            }, 100);
    } else {
        // Remove all inline style from jquery fadeIn function to reset menu state
        $('#side-menu').removeAttr('style');
    }
}

function destroyView(currentView) {
    //COMPLETELY UNBIND THE VIEW
    currentView.undelegateEvents();
    try {
        currentView.onDestroy();
    } catch (e) {

    }
    currentView.$el.removeData().unbind();
    //Remove view from DOM
    currentView.remove();
    Backbone.View.prototype.remove.call(currentView);
}

var NeoBackBonePrototype = function ($, _, Backbone) {
    var NeoBackboneView = function (options) {
        this.childViews = [];
        Backbone.View.apply(this, [options]);
    };
    _.extend(NeoBackboneView.prototype, Backbone.View.prototype, {
        removeView: function () {
            _.each(this.childViews, function (childView) {

                if (childView.intervalHandle != undefined) {
                    clearInterval(childView.intervalHandle);
                    childView.intervalHandle = undefined;
                }
                try {
                    childView.onDestroy();
                } catch (e) {

                }
                childView.removeView();
            }, this);
            if (typeof (this.intervalHandle) != 'undefined') {
                clearInterval(this.intervalHandle);
                this.intervalHandle = undefined;
            }
            this.childViews = [];
            destroyView(this);
        }
    });
    NeoBackboneView.extend = Backbone.View.extend;
    return NeoBackboneView;
};

function getTemplates(fileName, checkDivIfExists, callBack) {
    if ($('#' + checkDivIfExists).length == 0) {
        $.get('scripts/templates/' + fileName + '.html', function (data) {
            $('#wrapper').append(data);
            callBack();
        });
    } else {
        callBack();
    }
};

function isEmail(email) {
    var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    return regex.test(email);
  }

function abbreviateNumber(num) {
    if (num >= 1000000000) {
        return (num / 1000000000).toFixed(1).replace(/\.0$/, '') + 'G';
     }
     if (num >= 1000000) {
        return (num / 1000000).toFixed(1).replace(/\.0$/, '') + 'M';
     }
     if (num >= 1000) {
        return (num / 1000).toFixed(1).replace(/\.0$/, '') + 'K';
     }
     return num;
}

function loginCallback (e){
    $('.btn-login-check').find('span').remove();
    $('.login-error').html('');
    // window.location.href = "#adminDashboard"
    if (name && pass) {
        $(e.currentTarget).append('<span><i class="fa fa-spinner fa-spin m-l-xs" > </i></span>');
    }
    var service;
    var name = $('.user-name').val().trim();
    var pass = $('.login-pass').val().trim();
    
    var input = {
        "userName": name,
        "password": btoa(pass)
    };
    if(name && pass){
        loadService('userLoginCheck',input,function (json) {
            if(Object.keys(json.data).length !== 0){
                localStorage.setItem('session_logname', json.data.username);
                localStorage.setItem('session_userId', json.data.email);
                localStorage.setItem('session_userName', json.data.name);
                localStorage.setItem('session_userRole', json.data.role);
                role = json.data.role.toLowerCase().replace(/\b[a-z]/g, function(letter) {
                    return letter.toUpperCase();
                });
                localStorage.setItem('landingScreenOptions', 'landingScreen'+role);
                if (json.data.role == "patient" || json.data.role == "doctor"){
                    window.location.href = "#profileDetails";
                }else{
                    window.location.href = "#Dashboard";
                }

            }else {
                $('.active .login-userName').notify('User Not Exist', 'error')
            }
        })
    }
}

function signUpCallback (e){
    var service;
    var email = $('.user-email').val().trim();
    email_valid = isEmail(email)
    var input = {
        "email": email,
    };
    if(email_valid){
        loadService('signUpCheck',input,function (json) {
            if(json.data.success){
                var loginTemplate = _.template($('#register_next_template').html());
                $('#wrapper').html(loginTemplate({'email':email}));
                $('.userregister').click(function (e) {
                    registerUser(e)
                });
                $('.datetimepicker').datetimepicker({
                    maxDate:new Date(),
                    format: 'MM/DD/YYYY'
                });
            }else {
                $('.active .login-userName').notify('User Not Exist', 'error')
            }
        })
    }else{
        $.notify("Enter a Valid Email address", 'error');
    }
}

function registerUser (e) {
    localStorage.removeItem('session_logname');
    localStorage.removeItem('session_userId');
    localStorage.removeItem('session_userName');
    localStorage.removeItem('session_userRole');
    localStorage.removeItem('landingScreenOptions');
    var email = $('.user-email').val().trim();
    var firstname = $('.userfname').val().trim();
    var lastname = $('.userlname').val().trim();
    var dob = $('.userdob').val().trim();
    var gender = $('input[name="gender"]:checked').val();
    var address = $('.useraddress').val().trim();
    var city = $('.city-name').val().trim();
    var phone = $('.userphone').val().trim();
    var name = firstname+" "+lastname
    let input_data = {
        "email": email, 'name': name, 'date_of_birth': dob, 'gender': gender, 'address': address, 'phone': phone, 'user_name': email,
        'oxygen_need': false, 'patient_in_date': '', 'ward': '', 'lab_results': [], 'history': [], 'city': city, 'department': '', 'condition': '', 
        'doctor_id': '', 'hospital_name': '', 'hospital_id': ''
    }
    if(email && firstname && lastname && dob && gender && address && city && phone && name){
        loadService('signUp',input_data,function (json) {
            if(json.data.success){
                localStorage.setItem('session_logname', email);
                localStorage.setItem('session_userId', email);
                localStorage.setItem('session_userName', name);
                localStorage.setItem('session_userRole', 'patient');
                localStorage.setItem('landingScreenOptions', 'landingScreenPatient');
                window.location.href = "#profileDetails";
            }else {
                $.notify("User Registration Failed, Contact Admin", 'error');
            }
        })
    }else{
        $.notify("All fields are required, Please fill", 'error');
    }
    console.log(input_data)
}
