/*
 * Service Call methods
 */
//===================Service URLS==================
var ServiceURL = "http://127.0.0.1:17000/hw/v1"
//==================================================
var g_activeRequests = 0;
var prodFlag = false;
//=======================================================================

var methods = {
    callService: function (method) {
        var date1,
            date2,
            date3;
        var settings = {
            cache: true,
            type: "POST",
            async: true,
            crossDomain: true,
            dataType: "json",
            //contentType : "application/json",
            contentType: "application/x-www-form-urlencoded; charset=UTF-8",
            beforeSend: function () {
                g_activeRequests++;
                methods.showFullLoadScreen();
                date1 = new Date();
            },
            complete: function () {
                if (g_activeRequests == 0) {
                    methods.hideFullLoadScreen();
                }
            },
            success: function () {

            },
            error: function (errorMsg) {
                log(errorMsg);
            },
            afterSuccess: function (result) {
                date2 = new Date();
                diff = date2.getTime() - date1.getTime();
                date2 = new Date(diff);
                g_activeRequests--;
            },
            afterError: function (errorMsg) {
                if (errorMsg != null) {
                    var responseText = errorMsg.responseText;
                    if (responseText == undefined){
                        responseText = ['123', '1243', '']
                    }
                    if (responseText.indexOf("SessionExpired") > 0) {
                    } else {
                        date3 = new Date();
                        diff = date3.getTime() - date1.getTime();
                        date3 = new Date(diff);
                        log("Error CallBack for method " + JSON.stringify(errorMsg) + " and  " + settings.serviceURL +
                            ". Time taken(sec:ms)- " + date3.getSeconds() + ":" + date3.getMilliseconds());
                    }
                }
                g_activeRequests--;
            }
        };
        settings = $.extend(settings, method);
        settings.newSuccess = function (result, textStatus, xhr) {
            if (xhr.status == 200) {
                if (methods.ServiceResultValidator(result)) {
                    try {
                        if (typeof(result) != "undefined") {
                            settings.success(result);

                        } else {
                            window.alert('Server Error. Please try again!!!');
                        }
                    } catch (err) {
                        window.alert('Server Error. Please try again!!!');
                        console.log('Error in server response :' + err);
                        //throw err;
                    }
                    settings.afterSuccess(result);
                } else {
                    settings.afterError(result);
                }
            }
        };
        settings.newError = function (errorMsg, a, b) {
            try {
                settings.error(errorMsg);
            } catch (err) {
                log(err);
            }
            settings.afterError(errorMsg);
        };
        if (method.type)
            settings.type = method.type;

        return $.ajax({
            cache: settings.cache,
            beforeSend: settings.beforeSend,
            type: settings.type,
            async: settings.async,
            contentType: settings.contentType,
            crossDomain: settings.crossDomain,
            'access-control-allow-origin': '*',
            url: settings.serviceURL,
            data: settings.data,
            contentType: settings.contentType,
            dataType: settings.dataType,
            complete: settings.complete,
            success: settings.newSuccess,
            error: settings.newError
        });
    },
    ServiceResultValidator: function (serviceResultJSON) {
        if ((serviceResultJSON == undefined) || (serviceResultJSON == null)) {

        } else if (serviceResultJSON.ERROR != undefined) {
            // This is an error JSOn with proper stacktrace and ERROR message.
            if (!prodFlag) {
                notifyValidationMessage('Error: ', serviceResultJSON.responseText, "error");
            } else {
                notifyValidationMessage('Error: ', serviceResultJSON.responseText, "error");
            }
            // logging error to console
            log(serviceResultJSON.ERROR);
            return false;
        }
        return true;
        // else the returned JSON is valid so go ahead with normal processing.
    },

    showFullLoadScreen: function (external) {
        var loadScreen = $('#loadScrWrapFull');
        if (loadScreen.length == 0) {
            $('body').append('<div id="loadScrWrapFull" class="modal-backdrop in">' +
                '<div class="sk-spinner sk-spinner-cube-grid" style="position:fixed; left:50%; top:45%;"> ' +
                '<img src="resources/img/loading.gif" style="height: 50px; width: 50px"/> </div></div>');
        } else {
            $('#loadScrWrapFull').show();
            $('#loadScrWrapFull').css('display', "block");
        }
    },
    hideFullLoadScreen: function () {
        var loadScreen = $('body #loadScrWrapFull');
        if (loadScreen.length > 0) {

            loadScreen.hide();
            loadScreen.css('display', "none");
        }
    }
};

function ServiceInvoker(method) {
    if (typeof method === 'object' || !method) {
        return methods.callService.apply(this, arguments);
    } else
        $.error('Method ' + method + ' does not exist on jQuery.tooltip');
};

function log(text) {
    if ((window['console'] !== undefined)) {
        if (!(Object.prototype.toString.call(text) == '[object String]')) {
            console.log(text);
        }
    }
}

function loadService(serviceName, data, sucessCallBack, errorCallBack, type, addLoader, cssSelector) {
    g_ServiceDefinitions[serviceName].success = sucessCallBack;
    // if (typeof(data) == "undefined" || data == "") {
    //     data = "";
    // }
    if (typeof data == "object") {
        data = JSON.stringify(data);
    }
    g_ServiceDefinitions[serviceName].data = data;
    if (errorCallBack)
        g_ServiceDefinitions[serviceName].error = errorCallBack;
    if (type)
        g_ServiceDefinitions[serviceName].type = type;
    return ServiceInvoker(g_ServiceDefinitions[serviceName]);
}

var g_ServiceDefinitions = {

    userLoginCheck : {
        serviceURL: ServiceURL + "/login"
    },
    signUpCheck : {
        serviceURL: ServiceURL + "/signup/emailVerification"
    },
    signUp : {
        serviceURL: ServiceURL + "/signup"
    },
    userChangePassword: {
        serviceURL: ServiceURL + "/changePassword"
    },
    landingScreenAdmin: {
        serviceURL: "jsons/landingScreenAdmin.json"
    },
    landingScreenPatient: {
        serviceURL: "jsons/landingScreenPatient.json"
    },
    landingScreenDoctor : {
        serviceURL: "jsons/landingScreenDoctor.json"
    },
    landingScreenHospital : {
        serviceURL: "jsons/landingScreenHospital.json"
    },
    datasetLoaded : {
        serviceURL: "jsons/landingScreenAdmin.json"
    },
    DashboardLoad: {
        // serviceURL: "jsons/adminDashboardData.json"
        serviceURL: ServiceURL + "/dashboard"
    },
    bloodBanksDataLoad: {
        serviceURL: ServiceURL + "/bloodbank"
    },
    getBloodBankDetail: {
        serviceURL: ServiceURL + "/bloodbank/getDetails"
    },
    updateBloodBankDetail: {
        serviceURL: ServiceURL + "/bloodbank/updateDetails"
    },
    saveBloodBankDetail: {
        serviceURL: ServiceURL + "/bloodbank/saveDetails"
    },
    deleteBloodBank: {
        serviceURL: ServiceURL + "/bloodbank/delete"
    },
    hospitalsDataLoad: {
        serviceURL: ServiceURL + "/hospitals"
    },
    diseaseDetails: {
        serviceURL: ServiceURL + "/diseases"
    },
    doctorDetails: {
        serviceURL: ServiceURL + "/doctors"
    },
    patientDetails: {
        serviceURL: ServiceURL + "/patients"
    },
    profileDetails: {
        serviceURL: ServiceURL + "/profile"
    },
    medicalHistory: {
        serviceURL: ServiceURL + "/patients/medicalHistory"
    },
    addAppointment: {
        serviceURL: ServiceURL + "/patients/bookAppointment"
    },
    getAppointment: {
        serviceURL: ServiceURL + "/getAppointment"
    },
    deleteAppointment: {
        serviceURL: ServiceURL + "/deleteAppointment"
    },
    updateAppointment: {
        serviceURL: ServiceURL + "/updateAppointment"
    },
    consultPatient: {
        serviceURL: ServiceURL + "/consultPatient"
    },
    searchMedicine: {
        serviceURL: ServiceURL + "/search/medicine"
    },
    getSpecimen: {
        serviceURL: ServiceURL + "/labtest/specimen"
    },
    addPrescription: {
        serviceURL: ServiceURL + '/addPrescription'
    },
    hospitalAppointment: {
        serviceURL: ServiceURL + '/hospital/appointment'
    },
    submitFeedback: {
        serviceURL: ServiceURL + '/feedback'
    }
};
