require.config({
    "baseUrl": "scripts",
    "deps": [
        "main"
    ],
    "paths": {
        /* over all common libs start */
        "jquery": "../resources/js/jquery-3.2.1.min",
        "bootstrap": "../resources/js/bootstrap.min",
        "app": "../resources/js/app",
        "jquery-ui": "../resources/lib/plugins/jquery-ui/jquery-ui.min",
        "slimscroll": "../resources/js/jquery.slimscroll",
        "bundle": "../resources/js/Chart.bundle",
        "chart": "../resources/js/chart",
        "backbone": "../resources/lib/plugins/backbone/backbone-min",
        "serviceLayer": "../configurations/serviceLayer",
		"ace": "../resources/lib/ace",
		"aceElements": "../resources/lib/ace-elements",
        "underscore": "../resources/lib/plugins/backbone/lodash.min",
        "notify": "../resources/lib/notify",
        "datatables.net": "../resources/js/jquery.dataTables.min",
        "datatables": "../resources/js/dataTables.bootstrap4.min",
        "select2": "../resources/lib/plugins/select2/select2.min",
        "bootBox" : "../resources/lib/tmp/bootbox.min",
        "datetimepicker": "../resources/js/bootstrap-datetimepicker.min",
        "moment": "../resources/js/moment.min",
        "editable": "../resources/lib/plugins/editable/bootstrap-editable.min",
		
    },
    "shim": {
        "main": {
            "deps": [
                "jquery",
                "serviceLayer"
            ],
            "exports": "main"
        },
        "backbone": {
            "deps": [
                "jquery",
                "underscore"
            ],
            "exports": "Backbone"
        },
        "jsplumbdr": {
            "deps": [
                "jquery",
                "jquery-ui"
            ],
            "exports": "jsplumb"
        },
		"notify": {
            "deps": [
                "jquery"
            ],
            "exports": "notify"
        },
        "datetimepicker": {
            "deps": [
                "moment"
            ],
            "exports": "datetimepicker"
        }
    }
});
